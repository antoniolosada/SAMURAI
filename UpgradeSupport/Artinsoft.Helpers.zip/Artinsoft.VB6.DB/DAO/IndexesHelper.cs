﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Artinsoft.VB6.DB.DAO
{
    /// <summary>
    /// 
    /// </summary>
    public class IndexesHelper: List<IndexHelper>
    {
        /// <summary>
        /// 
        /// </summary>
        public IndexesHelper(): base()
        {
        }
    }
}
