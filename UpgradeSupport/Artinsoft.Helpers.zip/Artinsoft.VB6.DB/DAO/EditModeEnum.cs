﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Artinsoft.VB6.DB.DAO
{
    /// <summary>
    /// 
    /// </summary>
    public enum EditModeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        None = 0,
        /// <summary>
        /// 
        /// </summary>
        dbEditAdd,
        /// <summary>
        /// 
        /// </summary>
        dbEditNone,
        /// <summary>
        /// 
        /// </summary>
        dbEditInProgress
    }
}
