﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Artinsoft.Windows.Forms
{
    /// <summary>
    /// Event args that allow the user to cancel cell value updating.
    /// </summary>
    public class DataGridViewCellValueCancelEventArgs : DataGridViewCellValueEventArgs
    {
        bool _Cancel;

        /// <summary>
        /// Gets/sets if the the cell value change should be cancelled.
        /// </summary>
        public bool Cancel
        {
            get { return _Cancel; }
            set { _Cancel = value; }
        }
        /// <summary>
        /// Creates a DataGridViewCellValueCancelEventArgs class with a specified column and row.
        /// </summary>
        /// <param name="col">The row which is being updated.</param>
        /// <param name="row">The column which is being updated.</param>
        public DataGridViewCellValueCancelEventArgs(int col, int row) : base(col, row) { }
        /// <summary>
        /// Creates a DataGridViewCellValueCancelEventArgs class with a specified column and row, and the value that is being set.
        /// </summary>
        /// <param name="col">The row which is being updated.</param>
        /// <param name="row">The column which is being updated.</param>
        /// <param name="value">The proposed value for the cell.</param>
        public DataGridViewCellValueCancelEventArgs(int col, int row, object value) : base(col, row) { this.Value = value; }
    }

}
