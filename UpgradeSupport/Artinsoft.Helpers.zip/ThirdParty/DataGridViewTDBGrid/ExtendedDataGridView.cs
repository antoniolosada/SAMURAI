﻿// Author: mrojas
// Project: Artinsoft.Windows.Forms
// Path: D:\VbcSPP\src\Helpers\Artinsoft.Windows.Forms\ExtendedDataGridView
// Creation date: 8/6/2009 2:29 PM
// Last modified: 10/8/2009 10:32 AM

#region Using directives

using Artinsoft.VB6.DB.ADO;
using Artinsoft.VB6.DB.RDO;
using Artinsoft.Windows.Forms.Properties;
using Microsoft.VisualBasic.Compatibility.VB6;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;
#endregion

namespace Artinsoft.Windows.Forms
{
    /// <summary>
    /// This is class implements a component that extends the
    /// System.Windows.Forms.DataGridView control.  It adds new properties and also
    /// provides &quot;Compatibility&quot; support for some Grid controls commonly used
    /// in  VB6: MSFlexGrid and APEX TrueDBGrid
    /// </summary>
    partial class DataGridViewTrueDB
    {
        void ExtendedDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception is System.FormatException)
            {
                MessageBox.Show(e.Exception.Message);
                this.CancelEdit();
            }
        }
        void ExtendedDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
        }

        void ExtendedDataGridView_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control != null)
            {
                DataGridExtendedEditingControl dataGridExtendedEditingControl = e.Control as DataGridExtendedEditingControl;
                if (dataGridExtendedEditingControl!=null)
                {
                    AttachKeyEventsToControl(dataGridExtendedEditingControl._TextBox);
                }
                else
                    AttachKeyEventsToControl(e.Control);
            } 
        }

        /// <summary>
        /// Base on selection changed
        /// </summary>
        internal void BaseOnSelectionChanged(EventArgs e)
        {
            base.OnSelectionChanged(e);
        } // BaseOnSelectionChanged()


        class ExtendedDataGridViewPropertyFilter : ITypeDescriptorFilterService
        {

            internal ITypeDescriptorFilterService oldService;
            internal DesignerActionService designerActionService;
            //internal DesignerActionUIService designerActionUIService;
            DesignerActionList columnEditing;
            bool columnEditingRemoved;

            #region ITypeDescriptorFilterService Members

            public bool FilterAttributes(IComponent component, System.Collections.IDictionary attributes)
            {
                if (oldService != null)
                    oldService.FilterAttributes(component, attributes);
                return true;
            }

            public bool FilterEvents(IComponent component, System.Collections.IDictionary events)
            {
                if (oldService != null)
                    oldService.FilterEvents(component, events);
                return true;
            }

            public bool FilterProperties(IComponent component, System.Collections.IDictionary properties)
            {
                DataGridViewTrueDB grid = component as DataGridViewTrueDB;
                if (grid != null)
                {
                    //Initialize ColumnEditing actions
                    CacheColumnEditingActionList(component);
                    if (!grid.isInitializing)
                    {
                        SetPropertiesForDataGridView(component, properties);
                    }
                    return false;
                }
                else
                    if (oldService != null)
                        return oldService.FilterProperties(component, properties);
                    else
                        return true;
            }
            #endregion

            //private void SetPropertiesForTrueDBGrid(IComponent component, System.Collections.IDictionary properties)
            //{
            //}

            private void SetPropertiesForDataGridView(IComponent component, System.Collections.IDictionary properties)
            {
               if (designerActionService != null && columnEditing != null && columnEditingRemoved)
                {
                    designerActionService.Add(component, columnEditing);
                    columnEditingRemoved = false;

                }
            }
            private void CacheColumnEditingActionList(IComponent component)
            {
                if (designerActionService != null && columnEditing == null)
                {
                    try
                    {
                        DesignerActionListCollection designerActionList = designerActionService.GetComponentActions(component, ComponentActionsType.Component);
                        foreach (System.ComponentModel.Design.DesignerActionList dList in designerActionList)
                        {
                            if (dList.GetType().Name.Equals("DataGridViewColumnEditingActionList"))
                            {
                                this.columnEditing = dList;
                                break;
                            }
                        }
                    }
                    catch { }
                }
            }

        }


        internal void BaseClearSelection()
        {
            base.ClearSelection();
        }

        internal void BaseOnCellMouseDown(DataGridViewCellMouseEventArgs e)
        {
            base.OnCellMouseDown(e);
        }

        /// <summary>
        /// Allows access to the base data source
        /// </summary>
        internal object BaseDataSource
        {
            get
            {
                return base.DataSource;
            } // get
            set
            {
                base.DataSource = value;
            } // set
        } // BaseDataSource



        #region ISupportInitialize Members and Behaviour Switching Management

        private bool isInitializing = false;
        /// <summary>
        /// 
        /// </summary>
        public virtual void BeginInit()
        {
            isInitializing = true;
  
           // currentBehaviour.BeginInit();
        }
        /// <summary>
        /// Implements the ISupportInitialize.EndInit method.
        /// It sets the grid behavior according the Compatibility mode and delegates EndInit logic to the behaviour.
        /// </summary>
        public virtual void EndInit()
        {
               isInitializing = false;

            //We must set the datasource at the end
            if (!attachedEventsToDataTable)
            {
                AttachEventsToInternalDataTable();
            }
            backupNormal = RowsDefaultCellStyle.Clone();
            backupAlternating = AlternatingRowsDefaultCellStyle.Clone();
            AlternatingRows = _alternatingRows;
        }

        #endregion

        bool addHandlerForCommitOnFormClosing;

        /// <summary>
        /// When the form is closed by pressing the X button the Default windows forms handlers do  not commit the data that is 
        /// currently in edition on open grids.
        /// By default the grids will add handler to the containing form when the binding source is set.
        /// If you want to override this behaviour set this property to false.
        /// </summary>
        [Browsable(true), DefaultValue(true), Description("If set selects the full row when the user clicks the row header")]
        public bool AddHandlerForCommitOnFormClosing
        {
            get { return addHandlerForCommitOnFormClosing; }
            set { addHandlerForCommitOnFormClosing = value; }
        }


        bool allowRowSelection;

        /// <summary>
        /// If set selects the full row when the user clicks the row header
        /// </summary>
        [Browsable(true),DefaultValue(true),Description("If set selects the full row when the user clicks the row header")]
        public bool AllowRowSelection
        {
            get { return allowRowSelection; }
            set { allowRowSelection = value; }
        }

        void ExtendedDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (AllowRowSelection)
            {
                ClearSelection();
                foreach (DataGridViewColumn col in Columns)
                {
                    if (col.Visible)
                    {
                        CurrentCell = this[e.RowIndex, col.Index];
                        break;
                    } 
                    else
                        continue;
                    
                } // foreach
                DataGridViewRow currentRow = Rows[e.RowIndex];
                foreach (DataGridViewCell cell in currentRow.Cells)
                {
                    cell.Selected = true;
                }
            }
        }


        internal void BaseOnDataSourceChanged(EventArgs e)
        {
            base.OnDataSourceChanged(e);
        }

        DataGridViewCellStyle _oddStyle = null;
        /// <summary>
        /// Provides an style that will be used for odd rows (1,3,5,...) when the
        /// AlternatingRows property is true
        /// </summary>
        [Category("Appearance")]
        [Description("Provides an style that will be used for odd rows (1,3,5,...) when the AlternatingRows property is true")]
        public DataGridViewCellStyle OddStyle
        {
            get
            {
                if (_oddStyle == null)
                {
                    _oddStyle = AlternatingRowsDefaultCellStyle.Clone();
                } // if
                return _oddStyle;

            }
            set
            {
                if (_oddStyle == null || !_oddStyle.Equals(value))
                {
                    _oddStyle = value;
                    if (!isInitializing && _alternatingRows)
                    {
                        AlternatingRowsDefaultCellStyle = value;
                    } // if
                } // if

            }
        }

        DataGridViewCellStyle _evenStyle = null;
        /// <summary>
        /// Provides an style that will be used for even rows (0,2,4,...) when the
        /// AlternatingRows property is true
        /// </summary>
        [Category("Appearance")]
        [Description("Provides an style that will be used for even rows (0,2,4,...) when the AlternatingRows property is true")]
        public DataGridViewCellStyle EvenStyle
        {
            get
            {
                if (_evenStyle == null)
                {
                    _evenStyle = RowsDefaultCellStyle.Clone();
                } // if
                return _evenStyle;
            }
            set
            {
                if (_evenStyle == null || !_evenStyle.Equals(value))
                {
                    _evenStyle = value;
                    if (!isInitializing && _alternatingRows)
                    {
                        RowsDefaultCellStyle = value;
                    } // if
                } // if            
            }
        }

        DataGridViewCellStyle backupNormal = new DataGridViewCellStyle();
        DataGridViewCellStyle backupAlternating = new DataGridViewCellStyle();
        bool _alternatingRows;
        /// <summary>
        /// If true EvenStyle and OddStyle will be used to format the cells in the grid
        /// </summary>
        [Category("Appearance")]
        [Description("If true EvenStyle and OddStyle will be used to format the cells in the grid")]
        public bool AlternatingRows
        {
            get { return _alternatingRows; }
            set
            {
                _alternatingRows = value;
                if (!isInitializing)
                {
                    if (_alternatingRows)
                    {
                        backupNormal = RowsDefaultCellStyle.Clone();
                        backupAlternating = AlternatingRowsDefaultCellStyle.Clone();
                        RowsDefaultCellStyle = EvenStyle;
                        AlternatingRowsDefaultCellStyle = OddStyle;
                    } // if
                    else
                    {
                        RowsDefaultCellStyle = backupNormal;
                        AlternatingRowsDefaultCellStyle = backupAlternating;
                    } // else
                } // if
            }
        }

        /// <summary>
        /// Processes the Up and Down Keys to trigger KeyUp and KeyDown handlers
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            const int WM_KEYDOWN = 0x100;
//            const int WM_KEYUP = 0x101;
            KeyEventArgs keyevent;
            if (msg.Msg == WM_KEYDOWN)
            {
                keyevent = GetKeyEventArgs(keyData);
                if (keyevent != null)
                {
                    foreach (KeyEventHandler handler in keydownevents)
                    {
                        handler.Invoke(this, keyevent);
                    } // foreach
                    if (keyevent.Handled)
                        return true;
                    if (keyevent != null)
                    {
                        foreach (KeyEventHandler handler in keyupevents)
                        {
                            handler.Invoke(this, keyevent);
                        } // foreach
                        if (keyevent.Handled)
                            return true;
                    } // if
                } // if
            }
            return base.ProcessCmdKey(ref msg, keyData);

        }

        private static KeyEventArgs GetKeyEventArgs(Keys keyData)
        {
            KeyEventArgs keyevent = null;
            switch (keyData)
            {
                case Keys.Tab:
                    keyevent = new KeyEventArgs(Keys.Tab);
                    break;
                case Keys.Down:
                    keyevent = new KeyEventArgs(Keys.Down);
                    break;
                case Keys.Up:
                    keyevent = new KeyEventArgs(Keys.Up);
                    break;

            }
            return keyevent;
        }


        KeyEventHandler _controlKeyDown;
        KeyEventHandler _controlKeyUp;
        KeyPressEventHandler _controlKeyPress;
        DataGridViewEditingControlShowingEventHandler _EditingControlShowing;


        List<KeyEventHandler> keydownevents = new List<KeyEventHandler>();


        /// <summary>
        /// Hides DataGridView KeyDown Implementation to provide a functionality closer to the
        /// KeyDown event in VB6
        /// </summary>
        public new event KeyEventHandler KeyDown
        {
            add
            {
                keydownevents.Add(value);
                base.KeyDown += value;
            }
            remove
            {
                try { keydownevents.Remove(value); }
                catch { } // catch
                base.KeyDown -= value;
            }
        }



        List<KeyEventHandler> keyupevents = new List<KeyEventHandler>();


        /// <summary>
        /// Hides DataGridView KeyUp Implementation to provide a functionality closer to the
        /// KeyUp event in VB6
        /// </summary>
        public new event KeyEventHandler KeyUp
        {
            add
            {
                keyupevents.Add(value);
                base.KeyUp += value;
            }
            remove
            {
                try { keyupevents.Remove(value); }
                catch { } // catch
                base.KeyUp -= value;
            }
        }
 

        

        internal void AttachKeyEventsToControl(Control control)
        {
            control.KeyDown -= _controlKeyDown;
            control.KeyPress -= _controlKeyPress;
            control.KeyUp -= _controlKeyUp;


            control.KeyDown += _controlKeyDown;
            control.KeyPress += _controlKeyPress;
            control.KeyUp += _controlKeyUp;
        }

        void control_KeyUp(object sender, KeyEventArgs e)
        {
            foreach (KeyEventHandler handler in keyupevents)
            {
                handler.Invoke(sender, e);
            } // foreach

        }

        void control_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnKeyPress(e);
        }

        void control_KeyDown(object sender, KeyEventArgs e)
        {
            foreach (KeyEventHandler handler in keydownevents)
            {
                handler.Invoke(sender, e);
            } // foreach
        }
        /// <summary>
        /// 
        /// </summary>
        public int Col
        {
            get
            {
				if (CurrentCell != null)
				{
					return CurrentCell.ColumnIndex;
				}
				else
				{
					return -1;
				}
            }
            set
            {
				if (this.CurrentRow != null)
				{
					this.CurrentRow.Selected = true;
					if (this.CurrentRow.Cells.Count > value)
					{
						this.CurrentCell = this.CurrentRow.Cells[value];
					}
				}
				
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int Row
        {
            get
            {
                return 0;
            }
            set
            {
                //throw new NotImplementedException();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void MovePrevious()
        {
            if (this.DataSource is BindingSource)
            {
                ((BindingSource)this.DataSource).MovePrevious();
            }
            else if (this.DataSource is ADODataControlHelper)
            {
                BindingSource source = ((ADODataControlHelper)this.DataSource).Source;
                source.MovePrevious();
            }
            else if (this.DataSource is RDODataControlHelper)
            {
                BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
                source.MovePrevious();
            }
    }
    
        /// <summary>
        /// 
        /// </summary>
        public bool EOF
        {
            get
            { throw new NotImplementedException(); }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public object RowBookmark(int p)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// 
        /// </summary>
        public bool Bookmark {  
            get
            { throw new NotImplementedException(); }
        }
    }
    
}