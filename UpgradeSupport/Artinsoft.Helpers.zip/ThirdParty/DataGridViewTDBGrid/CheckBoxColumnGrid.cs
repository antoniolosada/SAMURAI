// Author: wquesada
// Project: Artinsoft.Windows.Forms.DataGridViewTDBGrid
// Path: \src\Helpers\Artinsoft.Windows.Forms\ExtendedDataGridView
// Creation date: 2/4/2011 3:18 PM

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;

namespace Artinsoft.Windows.Forms
{
    #region Class DataGridView Extended CheckBox Column

    /// <summary>
    /// Represents a column in a Artinsoft.Windows.Forms.ExtendedGridView
    /// </summary>
    [ToolboxBitmap(typeof(ResFinder), "Artinsoft.Windows.Forms.Resources.ToolColumn.bmp")]
    public class DataGridViewExtendedCheckBoxColumn : DataGridViewColumn
    {

        #region Constructor
        /// <summary>
        /// Default constructor for DataGridViewExtendedColumn. 
        /// Invokes DataGridExtendedCheckBoxCell default constructor
        /// </summary>
        public DataGridViewExtendedCheckBoxColumn()
            : base(new DataGridExtendedCheckBoxCell())
        {
        }
        #endregion

        #region New Properties

        /// <summary>
        /// Gets the design mode flag.
        /// </summary>
        internal bool InDesignMode
        {
            get
            {
                return Process.GetCurrentProcess().ProcessName == "devenv";
            }
        }

        ValueCollection _DisplayValues;
        /// <summary>
        /// The list of data to be displayed as combo options, or combo images (using the index in the image list)
        /// </summary>
        [Category("Values")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(ValueCollectionEditor), typeof(System.Drawing.Design.UITypeEditor))]
        [Description("The list of data to be displayed as combo options, or combo images (using the index in the image list)")]
        public ValueCollection DisplayValues
        {
            get
            {
                if (_DisplayValues == null)
                {
                    _DisplayValues = new ValueCollection();
                }
                return _DisplayValues;
            }
            set
            {
                _DisplayValues = value;
            }
        }

        private object _defaultNewRowValue;
        /// <summary>
        /// The default value for the column when editing a new row
        /// </summary>
        [Browsable(true), Description("The default value for the column when editing a new row"), Category("Data")]
        public object DefaultNewRowValue
        {
            get
            {
                return _defaultNewRowValue;
            }
            set
            {
                _defaultNewRowValue = value;
            }
        }

        /// <summary>
        /// Flag that determines if the Column has a Display Values table associated
        /// </summary>
        [Browsable(false)]
        public bool HasDisplayValues
        {
            get
            {
                return (DisplayValues != null && DisplayValues.Count > 0);
            }
        }

        private ImageList _imageList;
        /// <summary>
        /// Image list associated with the values of the column
        /// </summary>
        [Browsable(true), Description("Image list associated with the values of the column"), Category("Values")]
        public ImageList ImageList
        {
            get
            {
                return _imageList;
            }
            set
            {
                if (_imageList != value)
                {
                    _imageList = value;
                    if (_imageList != null && InDesignMode)
                    {
                        UseImageList = true;
                        Translate = true;
                    }
                    if (_imageList == null && InDesignMode)
                    {
                        UseImageList = false;
                    }
                }
            }
        }

        private bool _useImageList;
        /// <summary>
        /// Determines if the Image List is going to be used to display the image options
        /// </summary>
        [Description("Determines if the Image List is going to be used to display the options"), Category("Values"), DefaultValue(false)]
        public bool UseImageList
        {
            get
            {
                return _useImageList;
            }
            set
            {
                _useImageList = value;
            }
        }

        bool _cycleOnClick;
        /// <summary>
        /// When the user click the cell the value cycle between its Values associated
        /// </summary>
        [Description("When the user click the cell the value cycle between its Values associated"), Category("Values"), DefaultValue(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool CycleOnClick
        {
            get
            {
                return _cycleOnClick;
            }
            set
            {
                _cycleOnClick = value;
            }
        }

        bool _SortItems;
        /// <summary>
        /// Sort the items of its table associated
        /// </summary>
        [Description("Sort the items of its table associated"), Category("Values"), DefaultValue(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool SortItems
        {
            get
            {
                return _SortItems;
            }
            set
            {
                _SortItems = value;
            }
        }

        bool _translate;
        /// <summary>
        /// The value is displayed according to its table associated
        /// </summary>
        [Description("The value is displayed according to its table associated"), Category("Values"), DefaultValue(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool Translate
        {
            get
            {
                return _translate;
            }
            set
            {
                _translate = value;
            }
        }
        
        bool _annotatePicture;
        /// <summary>
        /// True when the user specify images the picture is displayed with the current value
        /// </summary>
        [Description("True when the user specify images the picture is displayed with the value"), Category("Values"), DefaultValue(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool AnnotatePicture
        {
            get
            {
                return _annotatePicture;
            }
            set
            {
                _annotatePicture = value;
            }
        }
        
        /// <summary>
        /// Gets the currently used DataGridExtendedCheckBoxCell CellTemplate value.
        /// </summary>
        [Browsable(false)]
        protected DataGridExtendedCheckBoxCell ExtendedGridCellTemplate
        {
            get
            {
                return (DataGridExtendedCheckBoxCell)CellTemplate;
            }
        }

        #endregion

        #region Overrides

        /// <summary>
        /// Clones the object to a new instance with all the attributes and state
        /// as the current instance
        /// </summary>
        /// <returns>The new cloned object</returns>
        public override object Clone()
        {
            DataGridViewExtendedCheckBoxColumn column = base.Clone() as DataGridViewExtendedCheckBoxColumn;
            if (column != null)
            {
                column.AnnotatePicture = AnnotatePicture;
                column.AutoSizeMode = AutoSizeMode;
                column.CycleOnClick = CycleOnClick;
                column.DefaultNewRowValue = DefaultNewRowValue;
                column.DisplayValues = DisplayValues;
                column.ImageList = ImageList;
                column.SortItems = SortItems;
                column.Translate = Translate;
                column.UseImageList = UseImageList;
            }
            return column;
        }

        /// <summary>
        /// Gets/Sets the current DataGridViewCell CellTemplate
        /// The value assigned to this property needs to be an ExtendedGridTextBoxButtonCell
        /// instance, otherwise, an exception is raised.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public override DataGridViewCell CellTemplate
        {
            get
            {
                return base.CellTemplate;
            }
            set
            {
                DataGridExtendedCheckBoxCell dataGridCell = value as DataGridExtendedCheckBoxCell;
                if (value != null && dataGridCell == null)
                {
                    throw new InvalidCastException("Value for CellTemplate has to be a ExtendedGridTextBoxButtonCell instance or descendant");
                }
                base.CellTemplate = value;
            }
        }
        #endregion
    }

    #endregion

    #region Class DataGrid Extended Cell

    /// <summary>
    /// The class that implements the cell for the Extended GridTextBoxButton Column
    /// It paints the image associated when it is required
    /// </summary>
    public class DataGridExtendedCheckBoxCell : DataGridViewCheckBoxCell
    {
        /// <summary>
        /// Gets the value used by default when adding a new row.  If DefaultNewRowValue
        /// cannot be properly determined locally, a call to the base DefaultNewRowValue is made.
        /// </summary>
        public override object DefaultNewRowValue
        {
            get
            {
                if (DataGridView != null && DataGridView.Columns != null)
                {
                    DataGridViewColumn column = DataGridView.Columns[ColumnIndex];
                    DataGridViewExtendedCheckBoxColumn extColumn = column as DataGridViewExtendedCheckBoxColumn;
                    if (extColumn != null && extColumn.DefaultNewRowValue != null)
                    {
                        return extColumn.DefaultNewRowValue;
                    }
                }
                return base.DefaultNewRowValue;
            }
        }

        /// <summary>
        /// Gets the value of the cell as formatted for display.
        /// If the cell is using value translation, then the formatted translated value is returned.
        /// </summary>
        /// <param name="value">The value to be formatted.</param>
        /// <param name="rowIndex">The index of the cell's parent row.</param>
        /// <param name="cellStyle">The DataGridViewCellStyle in effect for the cell.</param>
        /// <param name="valueTypeConverter">A TypeConverter associated with the value type that provides custom conversion to the formatted value type, or a null reference (Nothing in Visual Basic) if no such custom conversion is needed.</param>
        /// <param name="formattedValueTypeConverter">A TypeConverter associated with the formatted value type that provides custom conversion from the value type, or a null reference (Nothing in Visual Basic) if no such custom conversion is needed.</param>
        /// <param name="context">A bitwise combination of DataGridViewDataErrorContexts values describing the context in which the formatted value is needed.</param>
        /// <returns>The formatted value of the cell or a null reference (Nothing in Visual Basic) if the cell does not belong to a DataGridView control.</returns>
        protected override object GetFormattedValue(object value, int rowIndex, ref DataGridViewCellStyle cellStyle, TypeConverter valueTypeConverter, TypeConverter formattedValueTypeConverter, DataGridViewDataErrorContexts context)
        {
            try
            {
		if (value == null || Convert.IsDBNull(value)) return false;
                if (value.GetType() == typeof(string))
                {
                    if (value.ToString().ToLower() == "true")
                        return true;
                    else if (value.ToString().ToLower() == "false")
                        return false;
                    else
                        return System.Convert.ToBoolean(System.Convert.ToInt32(value));
                }
                return System.Convert.ToBoolean(value);
            }
            catch
            {
                return false;
            }
        }
        
        private DataGridViewExtendedCheckBoxColumn OwningExtendedColumn
        {
            get { return this.OwningColumn as DataGridViewExtendedCheckBoxColumn; }
        }
    }

    #endregion

}
