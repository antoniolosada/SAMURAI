using System;
//using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections.Specialized;
using System.Drawing.Design;
using System.Collections.Generic;
using System.Collections;
using Artinsoft.VB6.DB.ADO;
using Artinsoft.VB6.DB.DAO;
using Artinsoft.VB6.DB.RDO;
using System.IO;
using Artinsoft.Windows.Forms;
using Artinsoft.Windows.Forms.Properties;
using System.Diagnostics;
using System.ComponentModel.Design;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using Artinsoft.VB6.Gui;

internal class ResFinder { }

namespace Artinsoft.Windows.Forms
{
    /// <summary>
    /// List of constants used to support column's NumberFormat property
    /// </summary>
    public static class NumberFormatConstants
    {
        /// <summary>
        /// Display number as is, with no thousand separators.
        /// </summary>
        public const string GeneralNumber = "G";
        /// <summary>
        /// Display number with thousand separator, if appropriate; display two digits to the right of the 
        /// decimal separator. Note that output is based on system locale settings.
        /// </summary>
        public const string Currency = "C";
        /// <summary>
        /// Display number with thousands separator, at least one digit to the left and two digits to the 
        /// right of the decimal separator.
        /// </summary>
        public const string Standard = "N2";
        /// <summary>
        /// Display number multiplied by 100 with a percent sign (%) appended to the right; always display 
        /// two digits to the right of the decimal separator.
        /// </summary>
        public const string Percent = "#.00%";
    }

    /// <summary>
    /// Delegate to handle ExtendedDataGridView cell updating events.
    /// </summary>
    /// <param name="sender">The sender of the event.</param>
    /// <param name="e">The event arguments.</param>
    public delegate void DataGridViewCellValueCancelEventHandler(object sender, DataGridViewCellValueCancelEventArgs e);

    /// <summary>
    /// This is class implements a component that extends the
    /// System.Windows.Forms.DataGridView control.  It adds new properties and also
    /// provides &quot;Compatibility&quot; support for some Grid controls commonly used
    /// in  VB6: MSFlexGrid and APEX TrueDBGrid
    /// </summary>
    [ToolboxBitmap(typeof(ResFinder), "Artinsoft.Windows.Forms.Resources.ToolGrid.bmp")]
    public partial class DataGridViewTrueDB : DataGridView, ISupportInitialize
    {
        private DataColumnChangeEventHandler _DataColumnChangedHandler;
        private DataColumnChangeEventHandler _DataColumnChangingHandler;
        private DataRowChangeEventHandler _RowDeletedHandler;
        private DataRowChangeEventHandler _RowDeletingHandler;


        internal void InitializeTDBGEventHandlers()
        {
            _DataColumnChangedHandler = new DataColumnChangeEventHandler(_CurrentDataTable_ColumnChanged);
            _DataColumnChangingHandler = new DataColumnChangeEventHandler(_CurrentDataTable_ColumnChanging);

            _RowDeletedHandler = new DataRowChangeEventHandler(_CurrentDataTable_RowDeleted);
            _RowDeletingHandler = new DataRowChangeEventHandler(_CurrentDataTable_RowDeleting);

            //_RowAddedHandler = new DataTableNewRowEventHandler(_CurrentDataTable_RowAdded);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="container"></param>
        public DataGridViewTrueDB(IContainer container)
        {
            InitializeComponent();

            //At this point compatibility is DataGridView
            //this is to make sure that we have a valid currentbehaviour
            //and the DataGridView is the less complicated


            _controlKeyDown = new KeyEventHandler(control_KeyDown);
            _controlKeyUp = new KeyEventHandler(control_KeyUp);
            _controlKeyPress = new KeyPressEventHandler(control_KeyPress);
            _EditingControlShowing = new DataGridViewEditingControlShowingEventHandler(ExtendedDataGridView_EditingControlShowing);
            EditingControlShowing -= _EditingControlShowing;
            EditingControlShowing += _EditingControlShowing;
            this.CellFormatting += new DataGridViewCellFormattingEventHandler(ExtendedDataGridView_CellFormatting);
            this.DataError += new DataGridViewDataErrorEventHandler(ExtendedDataGridView_DataError);
            #region Designer related code

            IServiceContainer serviceContainer = container as IServiceContainer;
            if (serviceContainer != null)
            {
                ExtendedDataGridViewPropertyFilter newMyFilter = new ExtendedDataGridViewPropertyFilter();
                DesignerActionService designerActionService = serviceContainer.GetService(typeof(DesignerActionService)) as DesignerActionService;
                //DesignerActionUIService designerActionUIService = serviceContainer.GetService(typeof(DesignerActionUIService)) as DesignerActionUIService;
                newMyFilter.oldService = (ITypeDescriptorFilterService)serviceContainer.GetService(typeof(ITypeDescriptorFilterService));
                newMyFilter.designerActionService = designerActionService;
                //newMyFilter.designerActionUIService = designerActionUIService;
                if (newMyFilter.oldService != null)
                {
                    serviceContainer.RemoveService(typeof(ITypeDescriptorFilterService));
                }

                serviceContainer.AddService(typeof(ITypeDescriptorFilterService), newMyFilter);
            }

            #endregion
        }
        //private DataTableNewRowEventHandler _RowAddedHandler;

        private DataTable _CurrentDataTable;


        bool _isInitializing;
        /// <summary>
        /// Indicates if the grid is being initialized or not.
        /// </summary>
        public bool IsInitializing
        {
            get { return _isInitializing; }
            set { _isInitializing = true; }
        }

        #region Events from TrueDBGrid

        internal void RaiseCellUpdatedEvent(object sender, DataGridViewCellValueEventArgs e)
        {
            if (CellUpdated != null)
            {
                CellUpdated(sender, e);
            }
        }

        internal void RaiseCellUpdatingEvent(object sender, DataGridViewCellValueCancelEventArgs e)
        {
            if (CellUpdating != null)
            {
                CellUpdating(sender, e);
            }
        }

        internal void RaiseRowDeletedEvent(object sender, DataRowChangeEventArgs e)
        {
            if (RowDeleted != null)
            {
                RowDeleted(sender, e);
            }
        }

        internal void RaiseRowDeletingEvent(object sender, DataRowChangeEventArgs e)
        {
            if (RowDeleting != null)
            {
                RowDeleting(sender, e);
            }
        }

        internal void RaiseRowAddedEvent(object sender, DataTableNewRowEventArgs e)
        {
            if (RowAdded != null)
            {
                RowAdded(sender, e);
            }
        }

        /// <summary>
        /// Occurs after the data has updated its data source
        /// </summary>
        public event DataGridViewCellValueEventHandler CellUpdated;
        /// <summary>
        /// Occurs when the data is going to update its data source
        /// </summary>
        public event DataGridViewCellValueCancelEventHandler CellUpdating;
        /// <summary>
        /// Occurs after the record is deleted
        /// </summary>
        public event DataRowChangeEventHandler RowDeleted;
        /// <summary>
        /// Occurs before the record is deleting
        /// </summary>
        public event DataRowChangeEventHandler RowDeleting;
        /// <summary>
        /// Occurs when a new row is added
        /// </summary>
        public event DataTableNewRowEventHandler RowAdded;
        /// <summary>
        /// Occurs when the cell enters to edit mode
        /// </summary>
        public event DataGridViewCellEventHandler CellEdit;
        /// <summary>
        /// Occurs when the button of the column is clicked
        /// </summary>
        public event DataGridViewCellEventHandler ButtonClick;
        /// <summary>
        /// Occurs when the combo of the column is selected
        /// </summary>
        public event DataGridViewCellEventHandler ComboSelect;

        /// <summary>
        /// Fires up a new event called CellEdit just after the BeginEdit event is fired
        /// </summary>
        /// <param name="e">Event args of the cell</param>
        protected override void OnCellBeginEdit(DataGridViewCellCancelEventArgs e)
        {
            base.OnCellBeginEdit(e);
            if (!e.Cancel && CellEdit != null)
            {
                CellEdit(this, new DataGridViewCellEventArgs(e.ColumnIndex, e.RowIndex));
            }
        }

        internal void RaiseButtonClickEvent(object sender, int colIndex, int rowIndex)
        {
            if (ButtonClick != null)
            {
                DataGridViewCellEventArgs args = new DataGridViewCellEventArgs(colIndex, rowIndex);
                ButtonClick(sender, args);
            }
        }

        internal void RaiseComboSelectEvent(object sender, int colIndex, int rowIndex)
        {
            if (ComboSelect != null)
            {
                DataGridViewCellEventArgs args = new DataGridViewCellEventArgs(colIndex, rowIndex);
                ComboSelect(sender, args);
            }
        }
        #endregion

        #region Overriden Events

        /// <summary>
        /// Overrides base OnDataSourceChanged and delegates the handling of the event
        /// down onto the specific grid behaviour implementation.
        /// </summary>
        /// <param name="e">EventArgs instance</param>
        protected override void OnDataSourceChanged(EventArgs e)
        {
            if (!IsInitializing)
            {
                ReloadColumns();
            }
        }




        private void ReloadColumns()
        {
            AttachEventsToInternalDataTable();
        }

        private void AttachEventsToInternalDataTable()
        {
            DataTable table = GetInternalDataTable();
            if (table != null)
            {
                AttachEventsToDataTable(table);
            }
        }

        private void AttachEventsToDataTable(DataTable table)
        {
            if (_CurrentDataTable != null)
            {
                DetachEventsFromDataTable(_CurrentDataTable);
            }
            _CurrentDataTable = table;

            attachedEventsToDataTable = true;

            table.ColumnChanged -= _DataColumnChangedHandler;
            table.ColumnChanged += _DataColumnChangedHandler;

            table.ColumnChanging -= _DataColumnChangingHandler;
            table.ColumnChanging += _DataColumnChangingHandler;

            table.RowDeleted -= _RowDeletedHandler;
            table.RowDeleted += _RowDeletedHandler;

            table.RowDeleting -= _RowDeletingHandler;
            table.RowDeleting += _RowDeletingHandler;

            table.TableNewRow -= _CurrentDataTable_RowAdded;
            table.TableNewRow += _CurrentDataTable_RowAdded;

            attachedEventsToDataTable = true;
        }

        void _CurrentDataTable_RowAdded(object sender, DataTableNewRowEventArgs e)
        {
            RaiseRowAddedEvent(sender, e);
        }

        void _CurrentDataTable_RowDeleted(object sender, DataRowChangeEventArgs e)
        {
            RaiseRowDeletedEvent(sender, e);
        }

        void _CurrentDataTable_RowDeleting(object sender, DataRowChangeEventArgs e)
        {
            RaiseRowDeletingEvent(sender, e);
        }

        void _CurrentDataTable_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            int col = _CurrentDataTable.Columns.IndexOf(e.Column);
            int row = _CurrentDataTable.Rows.IndexOf(e.Row);
            if (row != -1)
            {
                DataGridViewCellValueEventArgs args = new DataGridViewCellValueEventArgs(col, row);
                args.Value = e.ProposedValue;
                RaiseCellUpdatedEvent(sender, args);
            }
        }

        void _CurrentDataTable_ColumnChanging(object sender, DataColumnChangeEventArgs e)
        {
            int col = _CurrentDataTable.Columns.IndexOf(e.Column);
            int row = _CurrentDataTable.Rows.IndexOf(e.Row);
            if (row != -1)
            {
                DataGridViewCellValueCancelEventArgs args = new DataGridViewCellValueCancelEventArgs(col, row, e.ProposedValue);
                RaiseCellUpdatingEvent(sender, args);
                if (args.Cancel)
                {
                    e.ProposedValue = _CurrentDataTable.Rows[row].ItemArray[col];
                }
            }
        }

        private void DetachEventsFromDataTable(DataTable table)
        {
            table.ColumnChanged -= _DataColumnChangedHandler;
            table.ColumnChanging -= _DataColumnChangingHandler;

            table.RowDeleted -= _RowDeletedHandler;
            table.RowDeleting -= _RowDeletingHandler;

            table.TableNewRow -= _CurrentDataTable_RowAdded;

            attachedEventsToDataTable = false;
        }

        private bool attachedEventsToDataTable = false;

		/// <summary>
		/// Shadows the base DataSource property to handle binding to DAO/RDO and ADO RecordSetHelperClasses 
		/// </summary>
		public new object DataSource
		{
			get { return base.DataSource; }
			set
			{
				if (value is ADODataControlHelper)
				{
					ADODataControlHelper dataControl = (ADODataControlHelper)value;
					base.DataSource = dataControl.Source;					
                     //Here we already know that this is a binding source and we need to add handler to commit values on closing
					Form contanining_form = this.FindForm();
					contanining_form.FormClosing -= formClosingHandler_Hack;
					contanining_form.FormClosing += formClosingHandler_Hack;
				}
				else if (value is DAODataControlHelper)
				{
					DAODataControlHelper dataControl = (DAODataControlHelper)value;
					base.DataSource = dataControl.Source;
					//Here we already know that this is a binding source and we need to add handler to commit values on closing
					Form contanining_form = this.FindForm();
					contanining_form.FormClosing -= formClosingHandler_Hack;
					contanining_form.FormClosing += formClosingHandler_Hack;
				}
				else
				{
					DataTable table = GetInternalDataTable(value);
					if (table != null && table.Rows.Count > 0)
					{
						base.DataSource = table;
					}
					else
					{
						base.DataSource = null;
					}
				}
			}
		}

		void Source_CurrentChanged(object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("Source_CurrentChanged");
		}

		FormClosingEventHandler formClosingHandler_Hack = new FormClosingEventHandler(contanining_form_FormClosing);

		static void contanining_form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Form containing_form = sender as Form;
			if (containing_form != null)
			{
				//This code is used to force a BindingSource ListChanged for a bound DataGRid when the containing form
				//is closed by pressing X
				IDataGridViewEditingControl activeCtrl = containing_form.ActiveControl as IDataGridViewEditingControl;
				if (activeCtrl != null)
				{
					DataGridView grid = activeCtrl.EditingControlDataGridView;
					if (grid.IsCurrentCellInEditMode)
					{
						DataGridViewCell savedOldCell = grid.CurrentCell;
						grid.SuspendLayout();
						//This hack forces a ListChanged notification event
						grid.CurrentCell = null;
						grid.CurrentCell = savedOldCell;
						grid.ResumeLayout();
					}
					grid.EndEdit();
				}
			}
			else
			{
				Debug.Assert(false, "No containing form was found for grid");
			}
		}
        private DataTable GetInternalDataTable()
        {
			return this.GetInternalDataTable(base.DataSource);
		}

        private DataTable GetInternalDataTable(object DataSource)
        {
            BindingSource binding = DataSource as BindingSource;
            DataTable table = null;
            if (binding != null)
            {
                DataSet dataSet = binding.DataSource as DataSet;
                if (dataSet != null && !string.IsNullOrEmpty(binding.DataMember))
                {
                    table = dataSet.Tables[binding.DataMember];
                }
                if (dataSet == null)
                {
                    // Case for DBArray
                    DataTable internalTable = binding.DataSource as DataTable;
                    if (internalTable != null)
                    {
                        table = internalTable;
                    }
                }
            }
            if (table == null)
            {
				DAODataControlHelper daoHelper = DataSource as DAODataControlHelper;
                ADODataControlHelper adoHelper = DataSource as ADODataControlHelper;
                if (adoHelper != null && adoHelper.Recordset != null && adoHelper.Recordset.Tables.Count > 0)
                {
                    table = adoHelper.Recordset.Tables[0];
                }else
                {
					if (daoHelper != null && daoHelper.Recordset != null && daoHelper.Recordset.Tables.Count > 0)
					{
						table = daoHelper.Recordset.Tables[0];
                }
                }
				if (adoHelper == null && daoHelper == null)
                {
                    RDODataControlHelper rdoHelper = DataSource as RDODataControlHelper;
                    if (rdoHelper != null && rdoHelper.Recordset != null && rdoHelper.Recordset.Tables.Count > 0)
                    {
                        table = rdoHelper.Recordset.Tables[0];
                    }
                }
            }
            return table;
        }



        #endregion

        #region Properties from TrueDBGrid

        /// <summary>
        /// Sets or returns the back color for the current selection.
        /// If multiple cells are selected it will return the first cell back color
        /// </summary>
        public Color SelectedBackColor
        {
            get
            {
                if (SelectedCells.Count > 1)
                {
                    return SelectedCells[0].Style.BackColor;
                }
                return SystemColors.AppWorkspace;
            }
            set
            {
                if (SelectedCells.Count > 1)
                {
                    foreach (DataGridViewCell cell in SelectedCells)
                    {
                        cell.Style.BackColor = value;
                    }
                }
            }
        }

        /// <summary>
        /// Sets or returns the fore color for the current selection.
        /// If multiple cells are selected it will return the first cell fore color
        /// </summary>
        public Color SelectedForeColor
        {
            get
            {
                if (SelectedCells.Count > 1)
                {
                    return SelectedCells[0].Style.ForeColor;
                }
                return SystemColors.AppWorkspace;
            }
            set
            {
                if (SelectedCells.Count > 1)
                {
                    foreach (DataGridViewCell cell in SelectedCells)
                    {
                        cell.Style.ForeColor = value;
                    }
                }
            }
        }

        /// <summary>
        /// Sets or returns the style for the current selection.
        /// If multiple cells are selected it will return the first cell style
        /// </summary>
        public DataGridViewCellStyle SelectedStyle
        {
            get
            {
                if (SelectedCells.Count > 1)
                {
                    return SelectedCells[0].Style;
                }
                return null;
            }
            set
            {
                if (SelectedCells.Count > 1)
                {
                    foreach (DataGridViewCell cell in SelectedCells)
                    {
                        cell.Style = value;
                    }
                }
            }
        }

        private DataGridViewCell _PreviousCell;

        /// <summary>
        /// Returns the previous cell before the user changed the current one
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataGridViewCell PreviousCell
        {
            get
            {
                return _PreviousCell;
            }
            set
            {
                _PreviousCell = value;
            }
        }

        /// <summary>
        /// Sets the previous cell when the user leaves the current one
        /// </summary>
        /// <param name="e">Argument with the cell to leave</param>
        protected override void OnCellLeave(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && e.ColumnIndex < this.ColumnCount)
            {
                PreviousCell = this[e.ColumnIndex, e.RowIndex];
            }
            base.OnCellLeave(e);
        }

        #endregion

        #region Selection Text Properties

        internal bool HasSelectionTextProperties
        {
            get
            {
                return (CurrentCell != null || CurrentCell is DataGridExtendedCell ||
                    CurrentCell is DataGridViewTextBoxCell || CurrentCell is DataGridViewComboBoxCell);
            }
        }

        /// <summary>
        /// Gets or sets a character index for the beginning of the current selection.
        /// </summary>
        public int SelStart
        {
            get
            {
                int result = -1;
                if (HasSelectionTextProperties)
                {
                    BeginEdit(false);
                    if (CurrentCell is DataGridExtendedCell)
                    {
                        DataGridExtendedEditingControl editControl = (DataGridExtendedEditingControl)EditingControl;
                        result = editControl._TextBox.SelectionStart;
                    }
                    else if (CurrentCell is DataGridViewTextBoxCell)
                    {
                        DataGridViewTextBoxEditingControl editControl = (DataGridViewTextBoxEditingControl)EditingControl;
                        result = editControl.SelectionStart;
                    }
                    else if (CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxEditingControl editControl = (DataGridViewComboBoxEditingControl)EditingControl;
                        result = editControl.SelectionStart;
                    }
                }
                return result;
            }
            set
            {
                if (HasSelectionTextProperties)
                {
                    BeginEdit(false);
                    if (CurrentCell is DataGridExtendedCell)
                    {
                        DataGridExtendedEditingControl editControl = (DataGridExtendedEditingControl)EditingControl;
                        editControl._TextBox.SelectionStart = value;
                    }
                    else if (CurrentCell is DataGridViewTextBoxCell)
                    {
                        DataGridViewTextBoxEditingControl editControl = (DataGridViewTextBoxEditingControl)EditingControl;
                        editControl.SelectionStart = value;
                    }
                    else if (CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxEditingControl editControl = (DataGridViewComboBoxEditingControl)EditingControl;
                        editControl.SelectionStart = value;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating the number of characters in the current selection in the text box.
        /// </summary>
        public int SelLength
        {
            get
            {
                int result = -1;
                if (HasSelectionTextProperties)
                {
                    BeginEdit(false);
                    if (CurrentCell is DataGridExtendedCell)
                    {
                        DataGridExtendedEditingControl editControl = (DataGridExtendedEditingControl)EditingControl;
                        result = editControl._TextBox.SelectionLength;
                    }
                    else if (CurrentCell is DataGridViewTextBoxCell)
                    {
                        DataGridViewTextBoxEditingControl editControl = (DataGridViewTextBoxEditingControl)EditingControl;
                        result = editControl.SelectionLength;
                    }
                    else if (CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxEditingControl editControl = (DataGridViewComboBoxEditingControl)EditingControl;
                        result = editControl.SelectionLength;
                    }
                }
                return result;
            }
            set
            {
                if (HasSelectionTextProperties)
                {
                    BeginEdit(false);
                    if (CurrentCell is DataGridExtendedCell)
                    {
                        DataGridExtendedEditingControl editControl = (DataGridExtendedEditingControl)EditingControl;
                        editControl._TextBox.SelectionLength = value;
                    }
                    else if (CurrentCell is DataGridViewTextBoxCell)
                    {
                        DataGridViewTextBoxEditingControl editControl = (DataGridViewTextBoxEditingControl)EditingControl;
                        editControl.SelectionLength = value;
                    }
                    else if (CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxEditingControl editControl = (DataGridViewComboBoxEditingControl)EditingControl;
                        editControl.SelectionLength = value;
                    }
                }
            }
        }

        /// <summary>
        /// Gets the content of the current selection in the text box.
        /// </summary>
        public string SelText
        {
            get
            {
                string result = string.Empty;
                if (HasSelectionTextProperties)
                {
                    BeginEdit(false);
                    if (CurrentCell is DataGridExtendedCell)
                    {
                        DataGridExtendedEditingControl editControl = (DataGridExtendedEditingControl)EditingControl;
                        result = editControl._TextBox.SelectedText;
                    }
                    else if (CurrentCell is DataGridViewTextBoxCell)
                    {
                        DataGridViewTextBoxEditingControl editControl = (DataGridViewTextBoxEditingControl)EditingControl;
                        result = editControl.SelectedText;
                    }
                    else if (CurrentCell is DataGridViewComboBoxCell)
                    {
                        DataGridViewComboBoxEditingControl editControl = (DataGridViewComboBoxEditingControl)EditingControl;
                        result = editControl.SelectedText;
                    }
                }
                return result;
            }
        }
        #endregion

        #region Methods from TrueDBGrid

        WeakReference weakRefToBindingSource = null;
        /// <summary>
        /// Disconnects the grid from the data source
        /// </summary>
        public void Close()
        {
            Close(true);
        }

        /// <summary>
        /// Disconnects the grid from the data source and optionally repaint the grid
        /// </summary>
        /// <param name="repaint">Determines if the gird should repaint</param>
        public void Close(bool repaint)
        {


        }

        /// <summary>
        /// Determines the rows to be exported
        /// </summary>
        public enum RowSelectorConstants
        {
            /// <summary>
            /// Apply Selector to all rows
            /// </summary>
            AllRows,
            /// <summary>
            /// Apply Selector to selected rows only
            /// </summary>
            SelectedRows,
            /// <summary>
            /// Apply Selector to current row only
            /// </summary>
            CurrentRow
        }

        /// <summary>
        /// Exports all rows from the grid to the specified file in html format
        /// </summary>
        /// <param name="pathname">Specifies the file where the rows are exported</param>
        /// <param name="append">The file will be appended or created</param>
        public void ExportToFile(string pathname, bool append)
        {
            ExportToFile(pathname, append, RowSelectorConstants.AllRows, string.Empty);
        }

        /// <summary>
        /// Exports the specified rows from the grid to the specified file in html format
        /// </summary>
        /// <param name="pathname">Specifies the file where the rows are exported</param>
        /// <param name="append">The file will be appended or created</param>
        /// <param name="selector">The rows to be exported</param>
        public void ExportToFile(string pathname, bool append, RowSelectorConstants selector)
        {
            ExportToFile(pathname, append, selector, string.Empty);
        }

        /// <summary>
        /// Exports the specified rows from the grid to the specified file in html format
        /// </summary>
        /// <param name="pathname">Specifies the file where the rows are exported</param>
        /// <param name="append">The file will be appended or created</param>
        /// <param name="selector">The rows to be exported</param>
        /// <param name="tableWidth">The width to the new html table</param>
        public void ExportToFile(string pathname, bool append, RowSelectorConstants selector, int tableWidth)
        {
            ExportToFile(pathname, append, selector, tableWidth.ToString());
        }

        /// <summary>
        /// Exports the specified rows from the grid to the specified file in html format
        /// </summary>
        /// <param name="pathname">Specifies the file where the rows are exported</param>
        /// <param name="append">The file will be appended or created</param>
        /// <param name="selector">The rows to be exported</param>
        /// <param name="tableWidth">The width to the new html table</param>
        public void ExportToFile(string pathname, bool append, RowSelectorConstants selector, string tableWidth)
        {

            StringBuilder htmlTable = new StringBuilder(Resources.HtmlTableTemplate);
            tableWidth = tableWidth == null ? string.Empty : tableWidth;
            if (tableWidth.Length > 0)
            {
                tableWidth = "width=\"" + tableWidth + "\"";
            }
            htmlTable.Replace("#table_width#", tableWidth);

            StringBuilder htmlTableHeaders = new StringBuilder();
            StringBuilder htmlTableRows = new StringBuilder();

            StreamWriter htmlFile = null;

            StringBuilder tmpLine = null;
            try
            {
                #region Headers Generation Code
                double columnsWidth = 0;
                double colWidth = 0;
                foreach (DataGridViewColumn column in Columns)
                {
                    columnsWidth += column.Width;
                }

                //Append the headers of the new Html Table
                if (ColumnHeadersVisible)
                {
                    foreach (DataGridViewColumn column in Columns)
                    {
                        tmpLine = new StringBuilder(Resources.HtmlTableHeaderTemplate);
                        tmpLine.Replace("#header_Text#", column.HeaderText);

                        colWidth = (column.Width * 100 / columnsWidth);
                        colWidth = Math.Round(colWidth, MidpointRounding.AwayFromZero);
                        tmpLine.Replace("#width#", colWidth.ToString());

                        htmlTableHeaders.AppendLine(tmpLine.ToString());
                    }
                }
                #endregion Headers Generation Code

                #region Rows Generation Code
                ICollection selectedRows = null;
                switch (selector)
                {
                    case RowSelectorConstants.AllRows:
                        selectedRows = Rows;
                        break;
                    case RowSelectorConstants.CurrentRow:
                        selectedRows = new List<DataGridViewRow>();
                        (selectedRows as IList).Add(CurrentRow);
                        break;
                    case RowSelectorConstants.SelectedRows:
                        selectedRows = SelectedRows;
                        break;
                }

                foreach (DataGridViewRow row in selectedRows)
                {
                    if (AllowUserToAddRows && row.Index == selectedRows.Count - 1)
                    {
                        break;
                    }

                    StringBuilder cellLines = new StringBuilder();
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        tmpLine = new StringBuilder(Resources.HtmlTableRowTemplate_Cell);
                        if (cell == null || cell.Value == null)
                        {
                            tmpLine.Replace("#cell_Text#", string.Empty);
                            tmpLine.Replace("#width#", string.Empty);
                        }
                        else
                        {
                            tmpLine.Replace("#cell_Text#", cell.Value.ToString());

                            colWidth = (cell.Size.Width * 100 / columnsWidth);
                            colWidth = Math.Round(colWidth, MidpointRounding.AwayFromZero);
                            tmpLine.Replace("#width#", colWidth.ToString());
                        }
                        cellLines.AppendLine(tmpLine.ToString());
                    }

                    StringBuilder rowLine = new StringBuilder(Resources.HtmlTableRowTemplate);
                    rowLine.Replace("#table_row_cells#", cellLines.ToString());
                    htmlTableRows.AppendLine(rowLine.ToString());
                }
                #endregion Rows Generation Code

                #region Formatting Html Code
                //Replacing the htmlHolders of the htmlTableTemplate with the new generated code
                htmlTable.Replace("#table_headers#", htmlTableHeaders.ToString());
                htmlTable.Replace("#table_rows#", htmlTableRows.ToString());
                #endregion Formatting Html Code

                #region Saving Html Code to the file
                //Open/Append/Create the file to write the html generated
                htmlFile = new StreamWriter(pathname, append);
                if (append)
                {
                    htmlFile.WriteLine();
                }
                htmlFile.Write(htmlTable.ToString());
                #endregion Saving Html Code to the file
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (htmlFile != null)
                {
                    htmlFile.Flush();
                    htmlFile.Close();
                    htmlFile = null;
                }
                htmlTable = null;
            }
        }

        /// <summary>
        /// Deletes the current row
        /// </summary>
        public void DeleteCurrentRow()
        {
            if (CurrentRow != null && !CurrentRow.IsNewRow)
            {
                try
                {
					BindingSource source = (BindingSource)this.DataSource;
					DAORecordSetHelper recorset = (DAORecordSetHelper)source.DataSource;                    
                    if (CurrentRow.Index >= recorset.RecordCount)
                    {
                        source.CancelEdit();
                    }
                    else
					recorset.Delete();
					//Rows.Remove(CurrentRow);
                }
                catch (Exception ex)
                {
                    if (!ex.Message.Equals("RowDeleting-Cancel", StringComparison.CurrentCultureIgnoreCase))
                    {
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Moves the current record to the first data record
        /// </summary>
        public void MoveFirst()
        {
            if (this.DataSource is BindingSource)
            {
                ((BindingSource)this.DataSource).MoveFirst();
            }
            else if (this.DataSource is ADODataControlHelper)
            {
                BindingSource source = ((ADODataControlHelper)this.DataSource).Source;
                source.MoveFirst();
            }
            else if (this.DataSource is RDODataControlHelper)
            {
                BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
                source.MoveFirst();
            }
            else if (this.DataSource is DataHelper)
            {
                BindingSource source = new BindingSource(((DataHelper)this.DataSource).Recordset, ((DataHelper)this.DataSource).Recordset.DataSet.Tables[0].TableName);
                source.MoveFirst();
            }
        }


        /// <summary>
        /// Moves to the next record 
        /// </summary>
        public void MoveNext()
        {
            if (this.DataSource is BindingSource)
            {
                ((BindingSource)this.DataSource).MoveNext();
            }
            else if (this.DataSource is ADODataControlHelper)
            {
                BindingSource source = ((ADODataControlHelper)this.DataSource).Source;
                source.MoveNext();
            }
            else if (this.DataSource is RDODataControlHelper)
            {
                BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
                source.MoveNext();
            }
            else if (this.DataSource is DataHelper)
            {
                BindingSource source = new BindingSource(((DataHelper)this.DataSource).Recordset, ((DataHelper)this.DataSource).Recordset.DataSet.Tables[0].TableName);
                source.MoveNext();
            }
        }


        /// <summary>
        /// Moves to the last record 
        /// </summary>
        public void MoveLast()
        {
            if (this.DataSource is BindingSource)
            {
                ((BindingSource)this.DataSource).MoveLast();
            }
            else if (this.DataSource is ADODataControlHelper)
            {
                BindingSource source = ((ADODataControlHelper)this.DataSource).Source;
                source.MoveLast();
            }
            else if (this.DataSource is RDODataControlHelper)
            {
                BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
                source.MoveLast();
            }
            else if (this.DataSource is DataHelper)
            {
                BindingSource source = new BindingSource(((DataHelper)this.DataSource).Recordset, ((DataHelper)this.DataSource).Recordset.DataSet.Tables[0].TableName);
                source.MoveLast();
            }
        }

        /// <summary>
        /// Repaints the current row
        /// </summary>
        public void RefreshCurrentRow()
        {
            if (!CurrentRow.IsNewRow)
                InvalidateRow(CurrentRow.Index);
        }

        /// <summary>
        /// Reconnects the grid to the data source
        /// </summary>
        public void ReOpen()
        {
            if (weakRefToBindingSource != null && weakRefToBindingSource.IsAlive)
            {
                this.DataSource = weakRefToBindingSource.Target;
                this.Enabled = true;
            }
            if (this.DataSource is BindingSource)
            {
                if (((BindingSource)this.DataSource).IsBindingSuspended)
                {
                    ((BindingSource)this.DataSource).ResumeBinding();
                }
                ((BindingSource)this.DataSource).ResetBindings(true);
            }
        }

        ///// <summary>
        ///// Gets/Sets the DataGridViewColumnCollection that stores the columns in the control
        ///// </summary>
        //public new DataGridViewColumnCollection Columns
        //{
        //    get
        //    {
        //        if (this.DataSource != null && base.DesignMode == true)
        //        {
        //            BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
        //            source.SuspendBinding();
        //        }

        //        return base.Columns;
        //    }
        //    set
        //    {
        //        if (value != null && value.Count > 0)
        //        {
        //            base.Columns.Clear();

        //            DataGridViewColumn[] _columns = new DataGridViewColumn[value.Count];
        //            while (value.Count > 0)
        //            {
        //                _columns[value.Count - 1] = value[value.Count - 1];
        //                value.RemoveAt(value.Count - 1);
        //            }

        //            base.Columns.AddRange(_columns);
        //        }
        //    }
        //}

        /// <summary>
        /// Reconnects the grid to the bound data source. Resets the columns, headings and other properties
        /// based on the current data source
        /// </summary>
        public void ReBind()
        {
            if (weakRefToBindingSource != null && weakRefToBindingSource.IsAlive)
            {
                this.DataSource = weakRefToBindingSource.Target;
                this.Enabled = true;
            }
            else
                if (this.DataSource is BindingSource)
                {
                    if (((BindingSource)this.DataSource).IsBindingSuspended)
                    {
                        ((BindingSource)this.DataSource).ResumeBinding();
                    }
                    ((BindingSource)this.DataSource).ResetBindings(false);
                }
                else if (this.DataSource is ADODataControlHelper)
                {
                    BindingSource source = ((ADODataControlHelper)this.DataSource).Source;
                    if (source.IsBindingSuspended)
                    {
                        source.ResumeBinding();
                    }
                    source.ResetBindings(false);
                }
                else if (this.DataSource is RDODataControlHelper)
                {
                    BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
                    if (source.IsBindingSuspended)
                    {
                        source.ResumeBinding();
                    }
                    source.ResetBindings(false);
                }
                else if (this.DataSource is DataHelper)
                {
                    BindingSource source = new BindingSource(((DataHelper)this.DataSource).Recordset.DataSet, ((DataHelper)this.DataSource).Recordset.DataSet.Tables[0].TableName);
                    if (source.IsBindingSuspended)
                    {
                        source.ResumeBinding();
                    }
                    source.ResetBindings(false);
                }
        }

        /// <summary>
        /// Repopulates the current row from the data source control and/or unbound events
        /// </summary>
        public void RefetchCurrentRow()
        {
            if (this.DataSource is BindingSource)
            {
                ((BindingSource)this.DataSource).ResetItem(((BindingSource)this.DataSource).Position);
            }
            else if (this.DataSource is ADODataControlHelper)
            {
                BindingSource source = ((ADODataControlHelper)this.DataSource).Source;
                source.ResetItem(((BindingSource)this.DataSource).Position);
            }
            else if (this.DataSource is RDODataControlHelper)
            {
                BindingSource source = ((RDODataControlHelper)this.DataSource).Source;
                source.ResetItem(((BindingSource)this.DataSource).Position);
            }
            else if (this.DataSource is DataHelper)
            {
                BindingSource source = new BindingSource(((DataHelper)this.DataSource).Recordset, ((DataHelper)this.DataSource).Recordset.DataSet.Tables[0].TableName);
                source.ResetItem(((BindingSource)this.DataSource).Position);
            }
        }

        /// <summary>
        /// Returns the index of the row of the specified coordinate value
        /// </summary>
        /// <param name="coordinate">defines the coordinate value</param>
        /// <returns>The index of the row</returns>
        public int RowContaining(int coordinate)
        {
            int rowIndex = -1;
            int rowTop = ColumnHeadersVisible == false ? Top : Top + ColumnHeadersHeight;

            DataGridViewElementStates displayOptions = DataGridViewElementStates.Displayed | DataGridViewElementStates.Visible;
            for (rowIndex = Rows.GetFirstRow(displayOptions); rowIndex != -1; rowIndex = Rows.GetNextRow(rowIndex, displayOptions, DataGridViewElementStates.None))
            {
                int rowBottom = rowTop + Rows[rowIndex].Height;
                if ((coordinate >= rowTop) && (coordinate <= rowBottom))
                {
                    break;
                }
                else
                {
                    rowTop = rowBottom;
                }
            }
            return rowIndex;
        }

        /// <summary>
        /// Forces the data of the current row to be updated to the database
        /// </summary>
        public void UpdateCurrentRow()
        {
            if (this.DataSource is ADODataControlHelper)
            {
                ((ADODataControlHelper)this.DataSource).Recordset.Update();
            }
            else if (this.DataSource is RDODataControlHelper)
            {
                ((RDODataControlHelper)this.DataSource).Recordset.Update();
            }
            else if (this.DataSource is DataHelper)
            {
                ((DataHelper)this.DataSource).Recordset.Update();
            }
        }

        #endregion

        #region Component Designer generated code

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private bool onDisposing = false;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            onDisposing = true;
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            onDisposing = false;
        }

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.CellMouseEnter -= new DataGridViewCellEventHandler(ExtendedDataGridView_CellMouseEnter);
            this.CellMouseEnter += new DataGridViewCellEventHandler(ExtendedDataGridView_CellMouseEnter);
            this.RowHeaderMouseClick -= new DataGridViewCellMouseEventHandler(ExtendedDataGridView_RowHeaderMouseClick);
            this.RowHeaderMouseClick += new DataGridViewCellMouseEventHandler(ExtendedDataGridView_RowHeaderMouseClick);
        }


        internal int mouse_cell_row = -1;
        internal int mouse_cell_column = -1;


        void ExtendedDataGridView_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            mouse_cell_row = e.RowIndex + (ColumnHeadersVisible ? 1 : 0);
            mouse_cell_column = e.ColumnIndex + (RowHeadersVisible ? 1 : 0);

        }


        #endregion



        #region ISupportInitialize Members


        void ISupportInitialize.EndInit()
        {
            //We must set the datasource at the end
            if (!attachedEventsToDataTable)
            {
                AttachEventsToInternalDataTable();
            }
        }

        #endregion


        #region Enums

        /// <summary>
        /// Sort Constants
        /// </summary>
        public enum SortSettings
        {
            /// <summary>
            /// Generic ascending sort
            /// </summary>
            SortGenericAscending = 1,
            /// <summary>
            /// Generic descending sort
            /// </summary>
            SortGenericDescending = 2,
            /// <summary>
            /// No Sort
            /// </summary>
            SortNone = 0,
            /// <summary>
            /// Numeric ascending sort
            /// </summary>
            SortNumericAscending = 3,
            /// <summary>
            /// Numeric descending sort
            /// </summary>
            SortNumericDescending = 4,
            /// <summary>
            ///  String ascending sort, case-sensitive
            /// </summary>
            SortStringAscending = 7,
            /// <summary>
            /// String descending sort, case-sensitive
            /// </summary>
            SortStringDescending = 8,
            /// <summary>
            /// String ascending sort, case-insensitive
            /// </summary>
            SortStringNoCaseAscending = 5,
            /// <summary>
            /// String descending sort, case-insensitive
            /// </summary>
            SortStringNoCaseDescending = 6
        }

        /// <summary>
        /// FillStyle Constants
        /// </summary>
        public enum FillStyleSettings
        {
            /// <summary>
            /// The Style Changes applies only to the Current Cell
            /// </summary>
            FillSingle = 0,
            /// <summary>
            /// The Style Changes applies to the Selected Cells
            /// </summary>
            FillRepeat = 1
        }

        /// <summary>
        /// AllowUserResizing Constants
        /// </summary>
        public enum AllowUserResizingSettings
        {
            /// <summary>
            /// None of the Columns or Rows could be Resized.
            /// </summary>
            ResizeNone = 0,
            /// <summary>
            /// Just Columns could be resized
            /// </summary>
            ResizeColumns = 1,
            /// <summary>
            /// Just Rows could be resized
            /// </summary>
            ResizeRows = 2,
            /// <summary>
            /// Both Rows and Columns be resized
            /// </summary>
            ResizeBoth = 3
        }



        /// <summary>
        /// Indicates the type of the Focus drawn in the control
        /// </summary>
        public enum FocusRectSettings
        {
            /// <summary>
            /// No Focus
            /// </summary>
            FocusNone = 0,
            /// <summary>
            /// Focus rect drawn lightly
            /// </summary>
            FocusLight = 1,
            /// <summary>
            /// Focus rect drawn more heavy
            /// </summary>
            FocusHeavy = 2
        }

        /// <summary>
        /// Indicates the type of Line used in the control
        /// </summary>
        public enum GridLineSettings
        {
            /// <summary>
            /// No Grid Line
            /// </summary>
            GridNone = 0,
            /// <summary>
            /// Plain type
            /// </summary>
            GridFlat = 1,
            /// <summary>
            /// Intern lines
            /// </summary>
            GridInset = 2,
            /// <summary>
            /// Extern Lines
            /// </summary>
            GridRaised = 3
        }

        /// <summary>
        /// Indicates highLight Type
        /// </summary>
        public enum HighLightSettings
        {
            /// <summary>
            /// Never Highlights
            /// </summary>
            HighlightNever = 0,
            /// <summary>
            /// Highlights always
            /// </summary>
            HighlightAlways = 1,
            /// <summary>
            /// Highlight With Focus
            /// </summary>
            HighlightWithFocus = 2
        }


        /// <summary>
        /// ScrollBar Constants
        /// </summary>
        public enum ScrollBarStyle
        {
            /// <summary>
            /// Neither Horizontal or Vertical ScrollBar
            /// </summary>
            ScrollBarNone = 0,
            /// <summary>
            /// Only Horizontal ScrollBar
            /// </summary>
            ScrollBarHorizontal = 1,
            /// <summary>
            /// Only Vertical ScrollBar
            /// </summary>
            ScrollBarVertical = 2,
            /// <summary>
            /// Both, Horizontal and Vertical ScrollBar
            /// </summary>
            ScrollBarBoth = 3
        }

        /// <summary>
        /// Controls the Style of the text
        /// </summary>
        public enum TextStyleSettings
        {
            /// <summary>
            /// Flat Text
            /// </summary>
            TextFlat = 0,
            /// <summary>
            /// Raised Text
            /// </summary>
            TextRaised = 1,
            /// <summary>
            /// Inset Text
            /// </summary>
            TextInset = 2,
            /// <summary>
            /// Raised Light
            /// </summary>
            TextRaisedLight = 3,
            /// <summary>
            /// Inset Light
            /// </summary>
            TextInsetLight = 4
        }

        #endregion


        #region Properties

        internal new bool DesignMode
        {
            get
            {
                return base.DesignMode;
            }
        }

        internal DataGridViewSelectionMode BaseSelectionMode
        {
            get { return base.SelectionMode; }
            set { base.SelectionMode = value; }
        }

        private DataGridViewCell _GeneralCurrentCell;

        private DataGridViewCell GeneralCurrentCell
        {
            get
            {
                if (_GeneralCurrentCell == null)
                {
                    _GeneralCurrentCell = this.CurrentCell;
                } // if
                return _GeneralCurrentCell;
            } // get
        }

        /// <summary>
        /// Avoids Focus Rectangle to be displayed. FocusRectangle is Managed in the Control
        /// </summary>
        protected override bool ShowFocusCues
        {
            get
            {
                return false;
            }
        }

        internal FillStyleSettings _fillStyle;

        /// <summary>
        /// Determines whether setting the Text property or one of the Cell formatting properties of a FlexGrid applies the change to all selected cells
        /// </summary>
        [Description("Determines whether setting the Text property or one of the Cell formatting properties of a FlexGrid applies the change to all selected cells"), Browsable(true), DefaultValue(ScrollBarStyle.ScrollBarBoth), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public FillStyleSettings FillStyle
        {
            get { return _fillStyle; }
            set { _fillStyle = value; }
        }

        /// <summary>
        /// Returns/sets the text contents of a cell or range of cells.
        /// </summary>
        [Description("Returns/sets the text contents of a cell or range of cells."), Browsable(true), DefaultValue(""), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public override string Text
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Value + "" : base.Text; }
            set
            {
                if (GeneralCurrentCell != null)
                    GeneralCurrentCell.Value = value;
                else
                    base.Text = value;
            }
        }

        /// <summary>
        /// Returns/sets the text contents of a cell or range of cells.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public object CellText
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Value : null; }
            set
            {
                if (GeneralCurrentCell != null)
                    GeneralCurrentCell.Value = value;
            }
        }



        /// <summary>
        /// Returns/sets the background and foreground colors of individual cells or ranges of cells.
        /// Provides compatibility with MSFlexGrid CellBackColor
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color CellBackColor
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.BackColor : BackColor; }
            set
            {
                if (_fillStyle == FillStyleSettings.FillSingle)
                {
                    if (GeneralCurrentCell != null)
                    {
                        if (!GeneralCurrentCell.HasStyle)
                        {
                            DataGridViewCellStyle style = new DataGridViewCellStyle(GeneralCurrentCell.Style);
                            style.BackColor = value;
                            GeneralCurrentCell.Style = style;
                        }
                        else
                        {
                            GeneralCurrentCell.Style.BackColor = value;
                        }
                    }
                }
                else
                {
                    foreach (DataGridViewCell dataGridViewCell in SelectedCells)
                    {
                        if (!dataGridViewCell.HasStyle)
                        {
                            DataGridViewCellStyle style = new DataGridViewCellStyle(dataGridViewCell.Style);
                            style.BackColor = value;
                            dataGridViewCell.Style = style;
                        }
                        else
                        {
                            dataGridViewCell.Style.BackColor = value;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Returns/sets the background and foreground colors of individual cells or ranges of cells.
        /// Provides compatibility with the MSFlexGrid CellForeColor
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color CellForeColor
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.ForeColor : ForeColor; }
            set
            {

                if (_fillStyle == FillStyleSettings.FillSingle)
                {
                    if (GeneralCurrentCell != null)
                    {
                        if (!GeneralCurrentCell.HasStyle)
                        {
                            DataGridViewCellStyle style = new DataGridViewCellStyle(GeneralCurrentCell.Style);
                            style.ForeColor = value;
                            GeneralCurrentCell.Style = style;
                        }
                        else
                        {
                            GeneralCurrentCell.Style.ForeColor = value;
                        }
                    }
                }
                else
                {
                    foreach (DataGridViewCell dataGridViewCell in SelectedCells)
                    {
                        if (!dataGridViewCell.HasStyle)
                        {
                            DataGridViewCellStyle style = new DataGridViewCellStyle(dataGridViewCell.Style);
                            style.ForeColor = value;
                            dataGridViewCell.Style = style;
                        }
                        else
                        {
                            dataGridViewCell.Style.ForeColor = value;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Returns/sets the alignment of data in a cell or range of selected cells. Not available at design time
        /// Provides compatibility with the MSFlexGrid CellAligment behaviour. DataGridViewContentAligment contants
        /// are used, but the property behaviour resembles the equivalent in MSFlexGrid
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataGridViewContentAlignment CellAlignment
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Alignment : DataGridViewContentAlignment.NotSet; }
            set
            {
                if (_fillStyle == FillStyleSettings.FillSingle)
                {
                    if (GeneralCurrentCell != null)
                    {
                        if (!GeneralCurrentCell.HasStyle)
                        {
                            DataGridViewCellStyle style = new DataGridViewCellStyle(GeneralCurrentCell.Style);
                            style.Alignment = value;
                            GeneralCurrentCell.Style = style;
                        }
                        else
                        {
                            GeneralCurrentCell.Style.Alignment = value;
                        }
                    }
                }
                else
                {
                    foreach (DataGridViewCell dataGridViewCell in SelectedCells)
                    {
                        if (!dataGridViewCell.HasStyle)
                        {
                            DataGridViewCellStyle style = new DataGridViewCellStyle(dataGridViewCell.Style);
                            style.Alignment = value;
                            dataGridViewCell.Style = style;
                        }
                        else
                        {
                            dataGridViewCell.Style.Alignment = value;
                        }
                    }
                }
            }
        }





        string _toolTipText = String.Empty;

        /// <summary>
        /// Gets/Sets the tool tip for the complete grid control
        /// </summary>
        public string ToolTipText
        {
            get
            {
                return _toolTipText;
            }
            set
            {
                _toolTipText = value;
            }
        }


        #region Font Settings

        private void SetCellFont(DataGridViewCell cell, Font font)
        {
            DataGridViewCellStyle style;
            if (cell.Style == DefaultCellStyle)
            {
                //Creates a new style for the Cell (Modifiying the DefaultCellStyle would change all the grid's Appereance)
                style = new DataGridViewCellStyle(DefaultCellStyle);
                cell.Style = style;
            }
            else
            {
                style = cell.Style;
            }
            style.Font = font;
        }

        private void SetCellFont(DataGridViewCell cell, FontStyle fontStyle, bool property)
        {
            DataGridViewCellStyle style = cell.Style;
            Font newFont;
            if (style.Font != null)
            {
                FontStyle newFontStyle = property ? style.Font.Style | fontStyle : style.Font.Style & ~fontStyle;
                newFont = new Font(style.Font, newFontStyle);
            }
            else
            {
                newFont = new Font(this.Font, property ? fontStyle : FontStyle.Regular);
            }

            SetCellFont(cell, newFont);
        }

        private void SetFontStyle(FontStyle style, bool property)
        {
            if (GeneralCurrentCell != null)
            {
                if (_fillStyle == FillStyleSettings.FillSingle)
                {
                    SetCellFont(GeneralCurrentCell, style, property);
                }
                else
                {
                    foreach (DataGridViewCell dataGridViewCell in SelectedCells)
                    {
                        SetCellFont(dataGridViewCell, style, property);
                    }
                }
            }
        }

        /// <summary>
        /// Returns or sets the bold style for the current cell text.
        /// Provides compatibility for MSFlexGrid
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool CellFontBold
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Font.Bold : false; }
            set { SetFontStyle(FontStyle.Bold, value); }
        }

        /// <summary>
        /// Returns or sets the bold style for the current cell text.
        /// Provides compatibility for MSFlexGrid
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool CellFontStrikeOut
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Font.Strikeout : false; }
            set { SetFontStyle(FontStyle.Strikeout, value); }
        }

        /// <summary>
        /// Returns or sets the italic style for the current cell text.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool CellFontItalic
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Font.Italic : false; }
            set { SetFontStyle(FontStyle.Italic, value); }
        }

        /// <summary>
        /// Returns or sets the underline style for the current cell text.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool CellFontUnderline
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Font.Underline : false; }
            set { SetFontStyle(FontStyle.Underline, value); }
        }

        /// <summary>
        /// Returns/sets the font to be used for individual cells or ranges of cells.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string CellFontName
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Font.Name : Font.Name; }
            set
            {
                string realName;
                switch (value)
                {
                    case "MS Sans Serif":
                        realName = "Microsoft Sans Serif";
                        break;
                    default:
                        realName = value;
                        break;
                }

                if (GeneralCurrentCell != null)
                {
                    if (_fillStyle == FillStyleSettings.FillSingle)
                    {
                        Font f = GeneralCurrentCell.Style.Font;
                        f = new Font(realName, f.Size, f.Style, f.Unit);
                        SetCellFont(GeneralCurrentCell, f);
                    }
                    else
                    {
                        foreach (DataGridViewCell dataGridViewCell in SelectedCells)
                        {
                            Font f = dataGridViewCell.Style.Font;
                            f = new Font(realName, f.Size, f.Style, f.Unit);
                            SetCellFont(dataGridViewCell, f);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Returns or sets the size, in points, for the current cell text.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public float CellFontSize
        {
            get { return GeneralCurrentCell != null ? GeneralCurrentCell.Style.Font.Size : Font.Size; }
            set
            {
                if (GeneralCurrentCell != null)
                {
                    if (_fillStyle == FillStyleSettings.FillSingle)
                    {
                        Font f = GeneralCurrentCell.Style.Font;
                        f = new Font(f.Name, value, f.Style, f.Unit);
                        SetCellFont(GeneralCurrentCell, f);
                    }
                    else
                    {
                        foreach (DataGridViewCell dataGridViewCell in SelectedCells)
                        {
                            Font f = dataGridViewCell.Style.Font;
                            f = new Font(f.Name, value, f.Style, f.Unit);
                            SetCellFont(dataGridViewCell, f);
                        }
                    }
                }
            }
        }

        #endregion

        /// <summary>
        /// Returns/sets the contents of the cells in a FlexGrid's selected region. Not available at design time.
        /// </summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Clip
        {
            get
            {
                ClipClass clipclass = new ClipClass();
                return clipclass.GetClip(GridCellCollectionToArray(SelectedCells));
            }
            set
            {

                ClipClass clipclass = new ClipClass();
                clipclass.SetClip(GridCellCollectionToArray(SelectedCells), value);
            }
        }

        private static DataGridViewCell[] GridCellCollectionToArray(DataGridViewSelectedCellCollection collection)
        {
            DataGridViewCell[] cells = new DataGridViewCell[collection.Count];
            int x = 0;
            foreach (DataGridViewCell cell in collection)
            {
                cells[x] = cell;
                x++;
            }
            return cells;
        }

        private Color? _foreColorFixed;
        /// <summary>
        ///  Determines the color used to draw text on each part of the FlexGrid.
        /// </summary>
        [Description(" Determines the color used to draw text on each part of the FlexGrid."), Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Color ForeColorFixed
        {
            get
            {
                if (_foreColorFixed == null)
                {
                    _foreColorFixed = ColumnHeadersDefaultCellStyle.ForeColor;
                }
                return _foreColorFixed.Value;
            }
            set
            {
                ColumnHeadersDefaultCellStyle.ForeColor = value;
                ColumnHeadersDefaultCellStyle.SelectionForeColor = value;
                RowHeadersDefaultCellStyle.ForeColor = value;
                RowHeadersDefaultCellStyle.SelectionForeColor = value;
                TopLeftHeaderCell.Style.ForeColor = value;
                TopLeftHeaderCell.Style.SelectionForeColor = value;

                foreach (DataGridViewColumn column in Columns)
                {
                    column.HeaderCell.Style.ForeColor = value;
                }

                foreach (DataGridViewRow row in base.Rows)
                {
                    row.HeaderCell.Style.ForeColor = value;
                }

                TopLeftHeaderCell.Style.ForeColor = value;
                _foreColorFixed = value;
            }
        }

        internal DataGridViewCell BaseCurrentCell
        {
            get
            {
                return base.CurrentCell;
            }
            set
            {
                base.CurrentCell = value;
            }
        }


        internal int BaseFirstDisplayedScrollingRowIndex
        {
            get
            {
                return base.FirstDisplayedScrollingRowIndex;
            }
            set
            {
                base.FirstDisplayedScrollingRowIndex = value;
            }
        }

        internal int BaseFirstDisplayedScrollingColumnIndex
        {
            get
            {
                return base.FirstDisplayedScrollingColumnIndex;
            }
            set
            {
                base.FirstDisplayedScrollingColumnIndex = value;
            }
        }



        internal DataGridViewTriState BaseWordWrap
        {
            get
            {
                return base.DefaultCellStyle.WrapMode;
            }
            set
            {
                base.DefaultCellStyle.WrapMode = value;
            }
        }


        #endregion

        #region Methods

        /// <summary>
        /// Removes a row from a FlexGrid control at run time
        /// </summary>
        /// <param name="index">The index of the Row</param>
        public void RemoveItem(int index)
        {
            if (index == 0)
            {
                if (ColumnHeadersVisible)
                    throw new InvalidOperationException("It's not possible to remove a Fixed Row");
            }
            index = ColumnHeadersVisible ? index - 1 : index;
            base.Rows.RemoveAt(index);
        }

        internal DataGridViewCell BaseGetCell(int columnindex, int rowindex)
        {
            return base[columnindex, rowindex];
        }

        internal void BaseSetCell(int columnindex, int rowindex, DataGridViewCell cell)
        {
            base[columnindex, rowindex] = cell;
        }

        private object ColumnHeadersTag;
        private object RowHeadersTag;

        /// <summary>
        /// Gets Array of long integer values with one item for each row (RowData) of the FlexGrid. Not available at design time.
        /// </summary>
        /// <param name="index">The index of the Row</param>
        /// <returns>The Data Stored on the Row</returns>
        public int get_RowData(int index)
        {
            if (index == 0)
            {
                if (ColumnHeadersVisible)
                    return ColumnHeadersTag != null ? (int)ColumnHeadersTag : 0;
            }

            int realindex = ColumnHeadersVisible ? index - 1 : index;
            return base.Rows[realindex].Tag != null ? (int)base.Rows[realindex].Tag : 0;
        }

        /// <summary>
        /// Sets Array of long integer values with one item for each row (RowData) of the FlexGrid. Not available at design time.
        /// </summary>
        /// <param name="index">The index of the Row</param>
        /// <param name="value">The Data to be Stored on the Row</param>
        public void set_RowData(int index, int value)
        {
            if (index == 0)
            {
                if (ColumnHeadersVisible)
                {
                    ColumnHeadersTag = value;
                    return;
                }
            }
            int realindex = ColumnHeadersVisible ? index - 1 : index;
            base.Rows[realindex].Tag = value;
        }

        /// <summary>
        /// This class manages the Column Data of a specified grid.
        /// </summary>
        public class ColDataProperty
        {
            internal DataGridViewTrueDB parent;
            /// <summary>
            /// Creates a ColDataProperty class for a specified grid.
            /// </summary>
            /// <param name="parent">The grid for which this class should be created.</param>
            public ColDataProperty(DataGridViewTrueDB parent) { this.parent = parent; }
            /// <summary>
            /// Gets/sets the Column Data property for the specified column.
            /// </summary>
            /// <param name="index">The index of the column.</param>
            /// <returns>The column data of the selected column.</returns>
            public int this[int index]
            {
                get
                {
                    if (index == 0)
                    {
                        if (parent.RowHeadersVisible)
                            return parent.RowHeadersTag != null ? (int)parent.RowHeadersTag : 0;
                    }
                    int realindex = parent.RowHeadersVisible ? index - 1 : index;
                    return parent.Columns[realindex].Tag != null ? (int)parent.Columns[realindex].Tag : 0;
                }
                set
                {
                    if (index == 0)
                    {
                        if (parent.RowHeadersVisible)
                        {
                            parent.RowHeadersTag = value;
                            return;
                        }
                    }
                    int realindex = parent.RowHeadersVisible ? index - 1 : index;
                    parent.Columns[realindex].Tag = value;
                }
            }
        }

        /// <summary>
        /// Gets/Sets Array of long integer values with one item for each column (ColData) of the FlexGrid.
        /// Not available at design time.
        /// </summary>
        [Browsable(false)]
        public ColDataProperty ColData
        {
            get
            {
                return new ColDataProperty(this);
            }
        }


        /// <summary>
        /// Returns True if the specified column is visible.
        /// </summary>
        /// <param name="index">The index of the Column</param>
        /// <returns></returns>
        public bool get_ColIsVisible(int index)
        {
            if (index == 0)
            {
                return RowHeadersVisible;
            }
            int realindex = index - 1;
            return base.Columns[realindex].Visible;
        }

        /// <summary>
        /// Returns True if the specified row is visible.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool RowIsVisible(int index)
        {
            if (index == 0)
            {
                return ColumnHeadersVisible;
            }
            int realindex = index - 1;
            return base.Rows[realindex].Visible;
        }

        /// <summary>
        /// Sets/Gets the alignment of data in the fixed cells of a column.
        /// </summary>
        [Browsable(false)]
        public FixedAlignmentProperty FixedAlignment
        {
            get
            {
                return new FixedAlignmentProperty(this);
            }

        }

        /// <summary>
        /// Gets/Sets the alignment of data in a column. 
        /// Not available at design time (except indirectly through the FormatString property).
        /// </summary>
        [Browsable(false)]
        public ColAlignmentProperty ColAlignment
        {
            get
            {
                return new ColAlignmentProperty(this);
            }
        }


        /// <summary>
        /// Gets the distance in Pixels between the upper-left corner of the control and the upper-left corner of a specified column.
        /// </summary>
        [Browsable(false)]
        public ColPosProperty ColPos
        {
            get
            {
                return new ColPosProperty(this);
            }
        }

        /// <summary>
        /// Gets the distance in Pixels between the upper-left corner of the control and the upper-left corner of a specified row.
        /// </summary>
        [Browsable(false)]
        public RowPosProperty RowPos
        {
            get
            {
                return new RowPosProperty(this);
            }
        }

        /// <summary>
        /// Clears the contents of the FlexGrid. This includes all text, pictures, and cell formatting.
        /// </summary>
        public void Clear()
        {
            foreach (DataGridViewColumn col in base.Columns)
            {
                ClearCell(col.HeaderCell);
            } // foreach
            foreach (DataGridViewRow row in base.Rows)
            {
                ClearCell(row.HeaderCell);
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell != null)
                    {
                        ClearCell(cell);
                    } // if (cell!=null
                }
            }
        }

        private static void ClearCell(DataGridViewCell cell)
        {
            cell.ErrorText = String.Empty;
            cell.Value = null;
            cell.ToolTipText = String.Empty;
            cell.Style = new DataGridViewCellStyle();
        }


        /// <summary>
        /// Changes the value, if the setted value contains \0 chars, then those are removed
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        void ExtendedDataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

            DataGridViewCell cell;

            if (e.ColumnIndex < 0 && e.RowIndex < 0)
            {

                cell = TopLeftHeaderCell;

            }

            else if (e.ColumnIndex < 0)
            {

                cell = Rows[e.RowIndex].HeaderCell;

            }

            else if (e.RowIndex < 0)
            {

                cell = Columns[e.ColumnIndex].HeaderCell;

            }

            else
            {

                cell = this[e.ColumnIndex, e.RowIndex];

            }


            string value = Convert.ToString(cell.Value);

            if (value.IndexOf('\0') != -1)
            {

                cell.Value = value.Substring(0, value.IndexOf('\0'));

            }

        }


        #endregion

        #region Support Classes

        /// <summary>
        /// Class used to manage the Alignment properties of the columns of a grid.
        /// </summary>
        public class ColAlignmentProperty
        {
            internal DataGridViewTrueDB parent;
            /// <summary>
            /// Creates a ColumnAlignmentProperty class for a specified grid.
            /// </summary>
            /// <param name="parent">The grid for which to create this class.</param>
            public ColAlignmentProperty(DataGridViewTrueDB parent)
            { this.parent = parent; }
            /// <summary>
            /// Gets/sets the Alignment property for a specified column.
            /// </summary>
            /// <param name="index">The index of the column.</param>
            /// <returns>The Alignment property of the selected column.</returns>
            public DataGridViewContentAlignment this[int index]
            {
                get
                {
                    if (index == 0)
                    {
                        if (parent.RowHeadersVisible)
                        {
                            return parent.RowHeadersDefaultCellStyle.Alignment;
                        }
                    }
                    int realindex = parent.RowHeadersVisible ? index - 1 : index;
                    DataGridViewColumn column = parent.Columns[realindex];
                    return column.DefaultCellStyle.Alignment;

                }
                set
                {
                    if (index == 0)
                    {
                        if (parent.RowHeadersVisible)
                        {
                            parent.RowHeadersDefaultCellStyle.Alignment = value;
                            return;
                        }
                    }
                    int realindex = parent.RowHeadersVisible ? index - 1 : index;
                    DataGridViewColumn column = parent.Columns[realindex];
                    if (column.CellTemplate.Style == parent.DefaultCellStyle)
                    {
                        DataGridViewCellStyle style = new DataGridViewCellStyle(column.CellTemplate.Style);
                        style.Alignment = value;
                        column.CellTemplate.Style = style;
                        column.DefaultCellStyle = style;
                        if (column.HeaderCell.HasStyle)
                        {
                            if (column.HeaderCell.Style.Alignment == DataGridViewContentAlignment.NotSet)
                            {
                                column.HeaderCell.Style.Alignment = value;
                            }
                        }
                        else
                        {
                            column.HeaderCell.Style.Alignment = value;
                        }

                        foreach (DataGridViewRow row in parent.Rows)
                        {
                            if (row.Cells[realindex].Style == parent.DefaultCellStyle)
                            {
                                row.Cells[realindex].Style = style;
                            }
                            else
                            {
                                row.Cells[realindex].Style.Alignment = value;
                            }
                        }
                    }
                    else
                    {
                        column.CellTemplate.Style.Alignment = value;
                        column.DefaultCellStyle.Alignment = value;
                        if (column.HeaderCell.HasStyle)
                        {
                            if (column.HeaderCell.Style.Alignment == DataGridViewContentAlignment.NotSet)
                            {
                                column.HeaderCell.Style.Alignment = value;
                            }
                        }
                        else
                        {
                            column.HeaderCell.Style.Alignment = value;
                        }

                    }
                }
            }
        }

        /// <summary>
        /// Class used to access the indexed ColPos property.
        /// </summary>
        public class ColPosProperty
        {
            internal DataGridViewTrueDB parent;
            /// <summary>
            /// Creates a ColPosProperty class for the specified grid.
            /// </summary>
            /// <param name="parent">The grid to use to create the ColPosProperty class.</param>
            public ColPosProperty(DataGridViewTrueDB parent)
            {
                this.parent = parent;
            }
            /// <summary>
            /// Enumerate the columns of the grid.
            /// </summary>
            /// <param name="index">The index of the column</param>
            /// <returns>The ColPos value for the specified column.</returns>
            public int this[int index]
            {
                get
                {
                    if (index == 0)
                        return 0;
                    else
                    {
                        int result = parent.RowHeadersVisible ? parent.RowHeadersWidth : 0;
                        if (parent.FirstDisplayedCell.ColumnIndex <= index)
                        {
                            for (int i = parent.FirstDisplayedCell.ColumnIndex; i < index - 1; i++)
                            {
                                result += parent.Columns[i].Width;
                            }
                        }
                        else
                        {
                            for (int i = parent.FirstDisplayedCell.ColumnIndex; i > index - 1; i--)
                            {
                                result -= parent.Columns[i - 1].Width;
                            }
                        }
                        return result;
                    }
                }

            }

        }

        /// <summary>
        /// Enumeration class used to access the indexed ColPos property.
        /// </summary>
        public class RowPosProperty
        {
            internal DataGridViewTrueDB parent;
            /// <summary>
            /// Creates a RowPosProperty class for the specified grid.
            /// </summary>
            /// <param name="parent">The grid to use to create the RowPosProperty class.</param>
            public RowPosProperty(DataGridViewTrueDB parent)
            {
                this.parent = parent;
            }
            /// <summary>
            /// Enumerate the rows of the grid.
            /// </summary>
            /// <param name="index">The index of the rows</param>
            /// <returns>The RowPos value for the specified row.</returns>
            public int this[int index]
            {
                get
                {
                    if (index == 0)
                        return 0;
                    else
                    {
                        int result = parent.ColumnHeadersVisible ? parent.ColumnHeadersHeight : 0;
                        if (parent.FirstDisplayedCell.RowIndex <= index)
                        {
                            for (int i = parent.FirstDisplayedCell.RowIndex; i < index - 1; i++)
                            {
                                result += parent.Rows[i].Height;
                            }
                        }
                        else
                        {
                            for (int i = parent.FirstDisplayedCell.RowIndex; i > index - 1; i--)
                            {
                                result -= parent.Rows[i - 1].Height;
                            }
                        }
                        return result;
                    }
                }

            }

        }

        /// <summary>
        /// Enumeration class used to access the indexed FixedAlignment property.
        /// </summary>
        public class FixedAlignmentProperty
        {
            internal DataGridViewTrueDB parent;
            /// <summary>
            /// Creates a FixedAlignmentProperty class for a specified grid.
            /// </summary>
            /// <param name="parent">The grid for which to create the class.</param>
            public FixedAlignmentProperty(DataGridViewTrueDB parent) { this.parent = parent; }
            /// <summary>
            /// Obtains the FixedAlignment property for the specified column.
            /// </summary>
            /// <param name="index">The index of the column.</param>
            /// <returns>The Fixed Alignment of the column.</returns>
            public DataGridViewContentAlignment this[int index]
            {
                get
                {
                    if (index == 0)
                    {
                        if (parent.RowHeadersVisible)
                        {
                            return parent.RowHeadersDefaultCellStyle.Alignment;
                        }
                    }
                    int realindex = parent.RowHeadersVisible ? index - 1 : index;
                    DataGridViewColumn column = parent.Columns[realindex];
                    if (column.Frozen)
                        return column.DefaultCellStyle.Alignment;
                    else
                        return DataGridViewContentAlignment.NotSet;
                }
                set
                {
                    if (index == 0)
                    {
                        if (parent.RowHeadersVisible)
                        {
                            parent.RowHeadersDefaultCellStyle.Alignment = value;
                            return;
                        }
                    }
                    int realindex = parent.RowHeadersVisible ? index - 1 : index;
                    DataGridViewContentAlignment align = value;
                    align = align == DataGridViewContentAlignment.NotSet ? DataGridViewContentAlignment.MiddleLeft : align;
                    DataGridViewColumn column = parent.Columns[realindex];
                    if (column.Frozen)
                        column.DefaultCellStyle.Alignment = align;
                    else
                        column.HeaderCell.Style.Alignment = align;
                }
            }
        }


        private class ClipClass
        {
            private int minrow, mincol, maxrow, maxcol, rowcount, colcount;

            private void InitValues(DataGridViewCell[] cells)
            {
                minrow = int.MaxValue;
                mincol = int.MaxValue;
                maxrow = int.MinValue;
                maxcol = int.MinValue;
                rowcount = 0;
                colcount = 0;
                List<int> rows = new List<int>();
                List<int> cols = new List<int>();

                foreach (DataGridViewCell cell in cells)
                {
                    if (!rows.Contains(cell.RowIndex))
                    {
                        rows.Add(cell.RowIndex);
                        if (cell.RowIndex < minrow)
                            minrow = cell.RowIndex;

                        if (cell.RowIndex > maxrow)
                            maxrow = cell.RowIndex;
                    }
                    if (!cols.Contains(cell.ColumnIndex))
                    {
                        cols.Add(cell.ColumnIndex);
                        if (cell.ColumnIndex < mincol)
                            mincol = cell.ColumnIndex;

                        if (cell.ColumnIndex > maxcol)
                            maxcol = cell.ColumnIndex;
                    }
                }
                rowcount = rows.Count;
                colcount = cols.Count;
            }

            public string GetClip(DataGridViewCell[] cells)
            {
                if (cells.Length == 0)
                    return "";

                string[][] Content = GetContent(cells);
                return FormatContent(Content);
            }

            public string[][] GetContent(DataGridViewCell[] cells)
            {
                //Calculates the min, max and the count of rows and cols
                InitValues(cells);

                string[][] Content = new string[rowcount][];
                for (int i = 0; i < rowcount; i++)
                {
                    Content[i] = new string[colcount];
                }

                foreach (DataGridViewCell cell in cells)
                {
                    int rowpos = cell.RowIndex - minrow;
                    int colpos = cell.ColumnIndex - mincol;

                    Content[rowpos][colpos] = cell.Value + "";
                }
                return Content;
            }

            public string FormatContent(string[][] Content)
            {
                //Pass the content to a String
                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < rowcount; i++)
                {
                    for (int j = 0; j < colcount; j++)
                    {
                        stringBuilder.Append(Content[i][j]);
                        if (j + 1 != colcount)
                            stringBuilder.Append("\t");
                    }
                    if (i + 1 != rowcount)
                        stringBuilder.AppendLine();
                }
                return stringBuilder.ToString();
            }

            public void SetClip(DataGridViewCell[] cells, string value)
            {
                if (cells.Length == 0)
                    return;

                //Calculates the min, max and the count of rows and cols
                InitValues(cells);
                string[][] Content = new string[rowcount][];
                for (int i = 0; i < rowcount; i++)
                {
                    Content[i] = new string[colcount];
                }

                string[] rowValues = value.Split('\n', '\r');
                for (int i = 0; i < rowValues.Length && i + minrow <= maxrow; i++)
                {
                    string[] colValues = rowValues[i].Split('\t');
                    for (int j = 0; j < colValues.Length && j + mincol <= maxcol; j++)
                    {
                        Content[i][j] = colValues[j].Trim();
                    }
                }
                SetContent(Content, cells);
            }

            public void SetContent(string[][] Content, DataGridViewCell[] cells)
            {
                //Pass the value to the selected cells
                foreach (DataGridViewCell cell in cells)
                {
                    int rowpos = cell.RowIndex - minrow;
                    int colpos = cell.ColumnIndex - mincol;
                    if (Content[rowpos][colpos] != null)
                        cell.Value = Content[rowpos][colpos];
                }
            }
        }



        #endregion


        /// <summary>
        /// Returns the Cell in the given Row and Column
        /// </summary>
        /// <param name="rowindex">The Row</param>
        /// <param name="colIndex">The Column</param>
        /// <returns>The Cell specified</returns>
        public DataGridViewCell GetCell(int rowindex, int colIndex)
        {
            if (colIndex < 0 || rowindex < 0)
                return null;
            else if (colIndex == 0 && rowindex == 0)
            {
                if (RowHeadersVisible && ColumnHeadersVisible)
                    return TopLeftHeaderCell;
                else if (RowHeadersVisible)
                    return base.Rows[0].HeaderCell;
                else if (ColumnHeadersVisible)
                    return Columns[0].HeaderCell;
            }
            else if (colIndex == 0)
            {
                if (RowHeadersVisible && ColumnHeadersVisible)
                    return base.Rows[rowindex - 1].HeaderCell;
                else if (RowHeadersVisible)
                {
                    return base.Rows[rowindex].HeaderCell;
                }
                else if (ColumnHeadersVisible)
                    return this[0, rowindex - 1];
            }
            else if (rowindex == 0)
            {
                if (RowHeadersVisible && ColumnHeadersVisible)
                    return Columns[colIndex - 1].HeaderCell;
                else if (RowHeadersVisible)
                    return this[colIndex - 1, 0];
                else if (ColumnHeadersVisible)
                    return Columns[colIndex].HeaderCell;
            }

            if (ColumnHeadersVisible && RowHeadersVisible)
            {
                int realCol = ColumnHeadersVisible ? colIndex : colIndex - 1;
                int realRow = RowHeadersVisible ? rowindex : rowindex - 1;
                return this[realRow, realCol];
            }
            else if (RowHeadersVisible)
            {
                int realCol = colIndex - 1;
                int realRow = rowindex;
                return this[realCol, realRow];
            }
            else if (ColumnHeadersVisible)
            {
                int realCol = colIndex;
                int realRow = rowindex - 1;
                return this[realCol, realRow];
            }
            else
            {
                int realRow = rowindex;
                int realCol = colIndex;
                return this[realCol, realRow];
            }
        }


        /// <summary>
        /// Called when a Column Header is clicked.
        /// </summary>
        /// <param name="e">The Event arguments.</param>
        protected override void OnColumnHeaderMouseClick(DataGridViewCellMouseEventArgs e)
        {
            base.OnColumnHeaderMouseClick(e);
            foreach (DataGridViewColumn column in Columns)
            {
                column.Selected = (column.Index == e.ColumnIndex);
            }
        }



        /// <summary>
        /// Indicates if a value is numeric
        /// </summary>
        /// <param name="value">The object to be evaluated</param>
        /// <returns>True if it is numeric</returns>
        internal static bool IsNumeric(object value)
        {
            double d;
            if (value is int || value is Double)
                return true;
            else
            {
                string strValue = value as string;
                if (!string.IsNullOrEmpty(strValue) && Double.TryParse(strValue, out d))
                    return true;
            }

            return false;
        }

        Dictionary<String, object> tempValues;

        Dictionary<String, object> TempValue
        {
            get
            {
                if (tempValues == null)
                    tempValues = new Dictionary<string, object>();
                return tempValues;
            }
        }

        private void AddTempValue<T>(string key, T value)
        {
            if (TempValue.ContainsKey(key))
                TempValue[key] = value;
            else
                TempValue.Add(key, value);
        }

        private int GetIntTempValue(string key, int default_value)
        {
            if (TempValue.ContainsKey(key))
                return (int)TempValue[key];
            else
                return default_value;
        }

        #region IGridBehaviour Members

        /// <summary>
        /// Gets/sets the minimum row height allowed for the grid.
        /// </summary>
        public int RowHeightMin
        {
            get
            {
                if (IsInitializing)
                    return GetIntTempValue("RowHeightMin", -1);
                else
                    return Rows.Count > 0 ? Rows[0].MinimumHeight : 0;
            }
            set
            {
                if (IsInitializing)
                {
                    AddTempValue("RowHeightMin", value);
                }
                else
                {
                    if (DesignMode && value < 0)
                    {
                        throw new ArgumentException("RowHeightMin must be 0 or greater");
                    }
                    if (value > 0)
                    {
                        foreach (DataGridViewRow row in Rows)
                        {
                            row.MinimumHeight = value;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// It resets the grid to the default values
        /// </summary>
        public virtual void Reset()
        {
            EditMode = DataGridViewEditMode.EditOnEnter;
        }


        /// <summary>
        /// Gets/sets the word wrap behaviour of the grid.
        /// </summary>
        public DataGridViewTriState WordWrap
        {
            get
            {
                if (IsInitializing)
                {
                    return GetTempValue("WordWrap", DataGridViewTriState.NotSet);
                }
                else
                    return BaseWordWrap;
            }
            set
            {
                BaseWordWrap = value;
            }
        }

        private T GetTempValue<T>(string key, T default_value)
        {
            if (TempValue.ContainsKey(key))
                return (T)tempValues[key];
            else
                return default_value;
        }


        /// <summary>
        /// Gets the index of the row over which the mouse is hovering.
        /// </summary>
        public int MouseRow
        {
            get
            {
                return mouse_cell_row;
            }
        }
        /// <summary>
        /// Gets the index of the column over which the mouse is hovering.
        /// </summary>
        public int MouseCol
        {
            get { return mouse_cell_column; }
        }
        /// <summary>
        /// Gets/sets the amount of rows in the grid.
        /// </summary>
        public int RowsCount
        {
            get
            {
                if (IsInitializing)
                {
                    return GetIntTempValue("RowsCount", -1);
                }
                else
                    return Rows.Count;
            }
            set
            {
                if (IsInitializing)
                {
                    AddTempValue("RowsCount", value);
                }
                else
                {
                    if (Rows.Count < value)
                    {
                        int diff = value - Rows.Count;
                        Rows.Add(diff);
                    }
                    else if (Rows.Count > value)
                    {
                        int index = value - 1;
                        int diff = Rows.Count - value;
                        for (int i = Rows.Count - 1; i < index; i--)
                        {
                            Rows.RemoveAt(i);
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Gets/sets the amount of columns in the grid.
        /// </summary>
        public int ColumnsCount
        {
            get
            {
                if (IsInitializing)
                {
                    return GetIntTempValue("ColumnsCount", -1);
                }
                return Columns.Count;
            }
            set
            {
                if (IsInitializing)
                {
                    AddTempValue("ColumnsCount", value);
                }
                else
                {
                    if (Columns.Count < value)
                    {
                        int diff = value - Columns.Count;
                        for (int i = 0; i < diff; i++)
                            Columns.Add(new DataGridViewColumn());
                    }
                    else if (Rows.Count > value)
                    {
                        int index = value - 1;
                        int diff = Columns.Count - value;
                        for (int i = Columns.Count - 1; i < index; i--)
                        {
                            Columns.RemoveAt(i);
                        }
                    }
                }
            }
        }
        #endregion

        #region Unbound Events Management

        private bool InitUnboundGetRelativeBookmarkExec = false;
        /// <summary>
        /// Throws UnboundGetRelativeBookmark to initialize grid
        /// </summary>
        internal void InitUnboundGetRelativeBookmark()
        {
            ThrowUnboundGetRelativeBookmark(true);
        }

        /// <summary>
        /// Throws UnboundGetRelativeBookmark to refresh grid
        /// </summary>
        internal void UpdateUnboundGetRelativeBookmark()
        {
            ThrowUnboundGetRelativeBookmark(false);
        }

        /// <summary>
        /// Throws UnboundGetRelativeBookmark simulating the same behaviour of the VB6 corresponding event
        /// </summary>
        /// <param name="init">Indicated if grid is being initialized or updated</param>
        internal void ThrowUnboundGetRelativeBookmark(bool init)
        {
            int intStartLocation;
            if (this.Columns.Count > 0)
            {
                UnboundGetRelativeBookmarkEventArgs unboundGetRelativeBookmarkEventArgs = new UnboundGetRelativeBookmarkEventArgs(null, 1, null, 1);
                do
                {
                    OnUnboundGetRelativeBookmark(unboundGetRelativeBookmarkEventArgs);
                    if (!(unboundGetRelativeBookmarkEventArgs.StartLocation == null || unboundGetRelativeBookmarkEventArgs.NewLocation == null ||
                        string.IsNullOrEmpty(unboundGetRelativeBookmarkEventArgs.StartLocation.ToString()) ||
                        string.IsNullOrEmpty(unboundGetRelativeBookmarkEventArgs.NewLocation.ToString())))
                    {
                        object[] values = new object[this.Columns.Count];
                        for (int i = 0; i < this.Columns.Count; i++)
                        {
                            ClassicReadEventArgs classicReadEventArgs = new ClassicReadEventArgs(unboundGetRelativeBookmarkEventArgs.NewLocation, i, null);
                            OnClassicRead(classicReadEventArgs);
                            values[i] = classicReadEventArgs.Value;
                            if (!init)
                                this[i, Convert.ToInt32(classicReadEventArgs.Bookmark)].Value = values[i];
                        }
                        if (init)
                            this.Rows.Add(values);
                    }
                    if (unboundGetRelativeBookmarkEventArgs.NewLocation == null || string.IsNullOrEmpty(unboundGetRelativeBookmarkEventArgs.NewLocation.ToString()))
                    {
                        unboundGetRelativeBookmarkEventArgs.StartLocation = "0";
                        unboundGetRelativeBookmarkEventArgs.OffSet = -1;
                    }
                    else
                    {
                        if (unboundGetRelativeBookmarkEventArgs.StartLocation == null || string.IsNullOrEmpty(unboundGetRelativeBookmarkEventArgs.StartLocation.ToString()))
                            unboundGetRelativeBookmarkEventArgs.OffSet = 0;
                        else
                            unboundGetRelativeBookmarkEventArgs.OffSet = 1;
                        unboundGetRelativeBookmarkEventArgs.StartLocation = unboundGetRelativeBookmarkEventArgs.NewLocation;

                    }
                    unboundGetRelativeBookmarkEventArgs.NewLocation = null;
                } while (Int32.TryParse(unboundGetRelativeBookmarkEventArgs.StartLocation.ToString(), out intStartLocation) &&
                         (intStartLocation + unboundGetRelativeBookmarkEventArgs.OffSet) >= 0);
            }
        }

        /// <summary>
        /// Throws ClassicAdd event simulating the VB6 corresponding event
        /// </summary>
        internal void RaiseClassicAdd()
        {
            object newRowBookmark = null;
            object Value = null;
            for (int i = 0; i < this.Columns.Count; i++)
            {

                Value = this[i, this.CurrentCell.RowIndex].Value;
                ClassicAddEventArgs classicAddEventArgs = new ClassicAddEventArgs(newRowBookmark, i, Value);
                OnClassicAdd(classicAddEventArgs);
                if (classicAddEventArgs.NewRowBookmark == null || string.IsNullOrEmpty(classicAddEventArgs.NewRowBookmark.ToString())) break;
                else newRowBookmark = classicAddEventArgs.NewRowBookmark;
            }
            UpdateUnboundGetRelativeBookmark();
        }

        /// <summary>
        /// Throws ClassicWrite event simulating the VB6 corresponding event
        /// </summary>
        internal void RaiseClassicWrite()
        {
            object newRowBookmark = null;
            int col = -1;
            object Value = null;
            foreach (DataGridViewCell cell in changedCells)
            {
                if (cell != null)
                {
                    newRowBookmark = cell.RowIndex;
                    col = cell.ColumnIndex;
                    Value = cell.Value;
                }
                ClassicWriteEventArgs classicWriteEventArgs = new ClassicWriteEventArgs(newRowBookmark, col, Value);
                OnClassicWrite(classicWriteEventArgs);
            }
            UpdateUnboundGetRelativeBookmark();
        }

        /// <summary>
        /// OnPaint method is overloaded to simulate UnboundGetRelativeBookmark event
        /// </summary>
        /// <param name="e">The PaintEventArgs that contains the event data</param>
        protected override void OnPaint(PaintEventArgs e)
        {
            if (!InitUnboundGetRelativeBookmarkExec)
            {
                InitUnboundGetRelativeBookmark();
                InitUnboundGetRelativeBookmarkExec = true;
            }
            base.OnPaint(e);
        }

        /// <summary>
        /// Raises the UnboundGetRelativeBookmark event
        /// </summary>
        /// <param name="e">The UnboundGetRelativeBookmarkEventArgs that contains the event data</param>
        protected void OnUnboundGetRelativeBookmark(UnboundGetRelativeBookmarkEventArgs e)
        {
            if (UnboundGetRelativeBookmark != null)
            {
                UnboundGetRelativeBookmark(this, e);
            }
        }

        /// <summary>
        /// The UnboundGetRelativeBookmark event
        /// </summary>
        public event UnboundGetRelativeBookmarkEventHandler UnboundGetRelativeBookmark;

        /// <summary>
        /// The UnboundGetRelativeBookmark event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The UnboundGetRelativeBookmarkEventArgs that contains the event data</param>
        public delegate void UnboundGetRelativeBookmarkEventHandler(object sender, UnboundGetRelativeBookmarkEventArgs e);

        /// <summary>
        /// Provides data for UnboundGetRelativeBookmark event
        /// </summary>
        public class UnboundGetRelativeBookmarkEventArgs : EventArgs
        {
            private object startLocation;
            private int offSet;
            private object newLocation;
            private int approximatePosition;

            /// <summary>
            /// UnboundGetRelativeBookmarkEventArgs constructor
            /// </summary>
            public UnboundGetRelativeBookmarkEventArgs(object StartLocation, int OffSet, object NewLocation, int ApproximatePosition)
            {
                startLocation = StartLocation;
                offSet = OffSet;
                newLocation = NewLocation;
                approximatePosition = ApproximatePosition;
            }

            /// <summary>
            /// Bookmark that, together with Offset, specifies the row to be returned in NewLocation. A StartLocation of Null indicates a request for a row from BOF or EOF
            /// </summary>
            public object StartLocation
            {
                get { return startLocation;  }
                set { startLocation = value;  }
            }

            /// <summary>
            /// Specifies the relative position (from StartLocation) of the row to be returned in NewLocation. A positive number indicates a forward relative position; a negative number indicates a backward relative position
            /// </summary>
            public int OffSet
            {
                get { return offSet; }
                set { offSet = value; }
            }

            /// <summary>
            /// Variable that receives the bookmark of the row specified by StartLocation plus Offset. If the row specified is beyond the first or the last row (that is, beyond BOF or EOF), then NewLocation should be set to Null
            /// </summary>
            public object NewLocation
            {
                get { return newLocation; }
                set { newLocation = value; }
            }

            /// <summary>
            /// Variable that optionally receives the ordinal position of NewLocation
            /// </summary>
            public int ApproximatePosition
            {
                get { return approximatePosition; }
                set { approximatePosition = value; }
            }
        }

        /// <summary>
        /// Raises the ClassicRead event
        /// </summary>
        /// <param name="e">The ClassicReadEventArgs that contains the event data</param>
        protected void OnClassicRead(ClassicReadEventArgs e)
        {
            if (ClassicRead != null)
            {
                ClassicRead(this, e);
            }
        }

        /// <summary>
        /// The ClassicRead event
        /// </summary>
        public event ClassicReadEventHandler ClassicRead;

        /// <summary>
        /// The ClassicRead event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The ClassicReadEventArgs that contains the event data</param>
        public delegate void ClassicReadEventHandler(object sender, ClassicReadEventArgs e);

        /// <summary>
        /// Provides data for ClassicRead event
        /// </summary>
        public class ClassicReadEventArgs : EventArgs
        {
            private object bookmark;
            private int _col;
            private object _value;

            /// <summary>
            /// ClassicReadEventArgs constructor
            /// </summary>
            public ClassicReadEventArgs(object Bookmark, int col, object Value)
            {
                bookmark = Bookmark;
                _col = col;
                _value = Value;
            }

            /// <summary>
            /// Identifies the row being requested
            /// </summary>
            public object Bookmark
            {
                get { return bookmark; }
                set { bookmark = value; }
            }

            /// <summary>
            /// Identifies the column being requested
            /// </summary>
            public int col
            {
                get { return _col; }
                set { _col = value; }
            }

            /// <summary>
            /// Used to transfer unbound column data to the grid
            /// </summary>
            public object Value
            {
                get { return _value; }
                set { _value = value; }
            }

        }

        /// <summary>
        /// Raises the ClassicWrite event
        /// </summary>
        /// <param name="e">The ClassicWriteEventArgs that contains the event data</param>
        protected void OnClassicWrite(ClassicWriteEventArgs e)
        {
            if (ClassicWrite != null)
            {
                ClassicWrite(this, e);
            }
        }

        /// <summary>
        /// The ClassicRead event
        /// </summary>
        public event ClassicWriteEventHandler ClassicWrite;

        /// <summary>
        /// The ClassicWrite event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The ClassicWriteEventArgs that contains the event data</param>
        public delegate void ClassicWriteEventHandler(object sender, ClassicWriteEventArgs e);

        /// <summary>
        /// Provides data for ClassicWrite event
        /// </summary>
        public class ClassicWriteEventArgs : EventArgs
        {
            private object bookmark;
            private int _col;
            private object _value;

            /// <summary>
            /// ClassicWriteEventArgs constructor
            /// </summary>
            public ClassicWriteEventArgs(object Bookmark, int col, object Value)
            {
                bookmark = Bookmark;
                _col = col;
                _value = Value;
            }

            /// <summary>
            /// Identifies the row to be updated
            /// </summary>
            public object Bookmark
            {
                get { return bookmark; }
                set { bookmark = value; }
            }

            /// <summary>
            /// Identifies the column to be updated
            /// </summary>
            public int col
            {
                get { return _col; }
                set { _col = value; }
            }

            /// <summary>
            /// Used to transfer data from the grid to the unbound data source
            /// </summary>
            public object Value
            {
                get { return _value; }
                set { _value = value; }
            }

        }

        /// <summary>
        /// Raises the ClassicAdd event
        /// </summary>
        /// <param name="e">The ClassicAddEventArgs that contains the event data</param>
        protected void OnClassicAdd(ClassicAddEventArgs e)
        {
            if (ClassicAdd != null)
            {
                ClassicAdd(this, e);
            }
        }

        /// <summary>
        /// The ClassicAdd event
        /// </summary>
        public event ClassicAddEventHandler ClassicAdd;

        /// <summary>
        /// The ClassicAdd event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The ClassicAddEventArgs that contains the event data</param>
        public delegate void ClassicAddEventHandler(object sender, ClassicAddEventArgs e);

        /// <summary>
        /// Provides data for ClassicAdd event
        /// </summary>
        public class ClassicAddEventArgs : EventArgs
        {
            private object newRowBookmark;
            private int _col;
            private object _value;

            /// <summary>
            /// ClassicAddEventArgs constructor
            /// </summary>
            public ClassicAddEventArgs(object NewRowBookmark, int col, object Value)
            {
                newRowBookmark = NewRowBookmark;
                _col = col;
                _value = Value;
            }

            /// <summary>
            /// Must be set to a unique bookmark for subsequent references to the newly added row
            /// </summary>
            public object NewRowBookmark
            {
                get { return newRowBookmark; }
                set { newRowBookmark = value; }
            }

            /// <summary>
            /// Identifies the column to receive the new value
            /// </summary>
            public int col
            {
                get { return _col; }
                set { _col = value; }
            }

            /// <summary>
            /// Used to transfer the new data from the grid to the unbound data source
            /// </summary>
            public object Value
            {
                get { return _value; }
                set { _value = value; }
            }

        }


        /// <summary>
        /// OnRowsRemoved method is overloaded to simulate ClassicDelete grid event
        /// </summary>
        /// <param name="e">The DataGridViewRowsRemovedEventArgs that contains the event data</param>
        protected override void OnRowsRemoved(DataGridViewRowsRemovedEventArgs e)
        {
            base.OnRowsRemoved(e);
            if (ClassicDelete != null && ! onDisposing)
            {
                ClassicDelete(this, new ClassicDeleteEventArgs(e.RowIndex));
                UpdateUnboundGetRelativeBookmark();
            }
        }

        /// <summary>
        /// The ClassicDelete event
        /// </summary>
        public event ClassicDeleteEventHandler ClassicDelete;

        /// <summary>
        /// The ClassicDelete event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The ClassicDeleteEventArgs that contains the event data</param>
        public delegate void ClassicDeleteEventHandler(object sender, ClassicDeleteEventArgs e);

        /// <summary>
        /// Provides data for ClassicDelete event
        /// </summary>
        public class ClassicDeleteEventArgs : EventArgs
        {
            private object bookmark;

            /// <summary>
            /// ClassicDeleteEventArgs constructor
            /// </summary>
            public ClassicDeleteEventArgs(object Bookmark)
            {
                bookmark = Bookmark;
            }

            /// <summary>
            /// Identifies the row to be deleted
            /// </summary>
            public object Bookmark
            {
                get { return bookmark; }
                set { bookmark = value; }
            }
        }

        private bool validatingCellIsDirty = false;
        /// <summary>
        /// OnRowValidating method is overloaded to simulate BeforeUpdate grid event
        /// </summary>
        /// <param name="e">The DataGridViewCellCancelEventArgs that contains the event data</param>
        protected override void OnRowValidating(DataGridViewCellCancelEventArgs e)
        {
            base.OnRowValidating(e);
            validatingCellIsDirty = this.IsCurrentRowDirty;
            if (BeforeUpdate != null && validatingCellIsDirty)
            {
                BeforeUpdateEventArgs beforeUpdateEventArgs = new BeforeUpdateEventArgs(0);
                BeforeUpdate(this, beforeUpdateEventArgs);
                e.Cancel = beforeUpdateEventArgs.Cancel != 0;
            }
        }

        private List<DataGridViewCell> changedCells = new List<DataGridViewCell>();
        /// <summary>
        /// OnCurrentCellChanged collects all updated cells in current row
        /// </summary>
        /// <param name="e">The EventArgs that contains the event data</param>
        protected override void OnCurrentCellChanged(EventArgs e)
        {
            if (!changedCells.Contains(this.CurrentCell)) changedCells.Add(this.CurrentCell);
        }

        /// <summary>
        /// The BeforeUpdate event
        /// </summary>
        public event BeforeUpdateEventHandler BeforeUpdate;

        /// <summary>
        /// The BeforeUpdate event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The BeforeUpdateEventArgs that contains the event data</param>
        public delegate void BeforeUpdateEventHandler(object sender, BeforeUpdateEventArgs e);

        /// <summary>
        /// Provides data for BeforeUpdate event
        /// </summary>
        public class BeforeUpdateEventArgs : EventArgs
        {
            private int cancel;

            /// <summary>
            /// BeforeUpdateEventArgs constructor
            /// </summary>
            public BeforeUpdateEventArgs(int Cancel)
            {
                cancel = Cancel;
            }

            /// <summary>
            /// May be set to True to prevent the update from occurring
            /// </summary>
            public int Cancel
            {
                get { return cancel; }
                set { cancel = value; }
            }
        }

        /// <summary>
        /// OnRowValidated method is overloaded to simulate ClassicAdd, ClassicWrite and AfterUpdate grid events
        /// </summary>
        /// <param name="e">The DataGridViewCellEventArgs that contains the event data</param>
        protected override void OnRowValidated(DataGridViewCellEventArgs e)
        {
            base.OnRowValidated(e);
            if (validatingCellIsDirty)
            {
                if (addingNewRow)
                {
                    addingNewRow = false;
                    RaiseClassicAdd();
                }
                else
                    RaiseClassicWrite();
                if (AfterUpdate != null) AfterUpdate(this, new AfterUpdateEventArgs());
            }
            changedCells.Clear();
        }

        /// <summary>
        /// The AfterUpdate event
        /// </summary>
        public event AfterUpdateEventHandler AfterUpdate;

        /// <summary>
        /// The AfterUpdate event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The AfterUpdateEventArgs that contains the event data</param>
        public delegate void AfterUpdateEventHandler(object sender, AfterUpdateEventArgs e);

        /// <summary>
        /// Provides data for AfterUpdate event
        /// </summary>
        public class AfterUpdateEventArgs : EventArgs
        {
        }

        private bool addingNewRow = false;
        /// <summary>
        /// OnRowValidated method is overloaded to simulate OnAddNew grid events
        /// </summary>
        protected override void OnRowsAdded(DataGridViewRowsAddedEventArgs e)
        {
            base.OnRowsAdded(e);
            if (InitUnboundGetRelativeBookmarkExec)
            {
                addingNewRow = true;
                if (OnAddNew != null) OnAddNew(this, new OnAddNewEventArgs());
            }
        }

        /// <summary>
        /// The OnAddNew event
        /// </summary>
        public event OnAddNewEventHandler OnAddNew;

        /// <summary>
        /// The AfterUpdate event handler
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The OnAddNewEventArgs that contains the event data</param>
        public delegate void OnAddNewEventHandler(object sender, OnAddNewEventArgs e);

        /// <summary>
        /// Provides data for OnAddNew event
        /// </summary>
        public class OnAddNewEventArgs : EventArgs
        {
        }
        #endregion


        /// <summary>
        /// 
        /// </summary>
        public DataRow BookMark
        {
            get { throw new NotImplementedException(); }
        }
    }
}
