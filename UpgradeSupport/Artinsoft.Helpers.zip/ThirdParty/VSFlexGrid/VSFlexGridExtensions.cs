﻿using System;
using System.Collections.Generic;
using System.Text;
using C1.Win.C1FlexGrid;

namespace AvlControls
{
    /// <summary>
    /// This Class Provides Extra functionality to C1.Win.C1FlexGrid.C1FlexGrid
    /// in order to achieve silimar functionality to the VSFlexGrid
    /// </summary>
    public static class VSFlexGridExtensions
    {
        /// <summary>
        /// Collapsed Settings Enum
        /// </summary>
        public enum CollapsedSettings
        {
            /// <summary>
            /// Node is collapsed
            /// </summary>
            flexOutlineCollapsed,
            /// <summary>
            /// Node is expanded
            /// </summary>
            flexOutlineExpanded
        }

        /// <summary>
        /// Values cache for perfomance FindRow
        /// </summary>
        private static Dictionary<string, Dictionary<string, int>> cacheValuesFindRow = new Dictionary<string, Dictionary<string, int>>();

        /// <summary>
        /// Gets the Cell Font Bold Property
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static bool getCellFontBold(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static bool getCellFontBold(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.Font.Bold;
        }

        /// <summary>
        /// Gets the Cell Font Size Property
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static float getCellFontSize(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static float getCellFontSize(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.Font.Size;
        }

        /// <summary>
        /// Gets the FontUnderline Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static bool getCellFontUnderline(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static bool getCellFontUnderline(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.Font.Underline;
        }

        /// <summary>
        /// Gets the PictureAlignment Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static C1.Win.C1FlexGrid.ImageAlignEnum getCellPictureAlignment(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static C1.Win.C1FlexGrid.ImageAlignEnum getCellPictureAlignment(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.ImageAlign;
        }

        /// <summary>
        /// Gets the Alignment Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static C1.Win.C1FlexGrid.TextAlignEnum getCellAlignment(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static C1.Win.C1FlexGrid.TextAlignEnum getCellAlignment(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.TextAlign;
        }

        /// <summary>
        /// Gets the Checked Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static int getCellChecked(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static int getCellChecked(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.Checkbox == C1.Win.C1FlexGrid.CheckEnum.Checked ? 1 : 0;
        }

        /// <summary>
        /// Gets the TextDisplay Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static string getCellTextDisplay(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static string getCellTextDisplay(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            throw new NotImplementedException();
        }

        /// <summary>
        /// Gets the Data Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static object getCellData(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static object getCellData(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.UserData;
        }

        /// <summary>
        /// Gets the Text Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static string getCellText(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static string getCellText(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            //AIS-NOTE: Do not Change this 
            return range.Clip;
        }

        /// <summary>
        /// Gets the BackColor Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static System.Drawing.Color getCellBackColor(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static System.Drawing.Color getCellBackColor(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.BackColor;
        }

        /// <summary>
        /// Gets the ForeColor Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static System.Drawing.Color getCellForeColor(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static System.Drawing.Color getCellForeColor(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.StyleDisplay.ForeColor;
        }

        /// <summary>
        /// Gets the Picture Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
        /// <returns>The current value of the property in the range specified</returns>
#if TargetF2
        public static System.Drawing.Image getCellPicture(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static System.Drawing.Image getCellPicture(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            return range.Image;
        }

        /// <summary>
        /// Sets the Alignment Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellAlignment(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, C1.Win.C1FlexGrid.TextAlignEnum value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellAlignment(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, C1.Win.C1FlexGrid.TextAlignEnum value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            style.TextAlign = value;
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Sets the BackColor Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellBackColor(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Color value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellBackColor(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Color value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            if (System.Drawing.ColorTranslator.ToOle(value) == 0)
                style.BackColor = vsGrid.BackColor;
            else
                style.BackColor = value;
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Sets the Checked Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellChecked(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellChecked(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            range.Checkbox = value == 1 ? C1.Win.C1FlexGrid.CheckEnum.Checked : C1.Win.C1FlexGrid.CheckEnum.Unchecked;
        }

        /// <summary>
        /// Sets the TextDisplay Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellTextDisplay(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellTextDisplay(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            throw new NotImplementedException();
        }

        /// <summary>
        /// Sets the Data Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellData(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, object value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellData(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, object value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
            range.UserData = value;
        }

        /// <summary>
        /// Sets the Font.Size Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellFontSize(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, float value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellFontSize(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, float value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            style.Font = new System.Drawing.Font(style.Font.FontFamily, value, style.Font.Style);
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Sets the Font.Bold Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellFontBold(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, bool value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellFontBold(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, bool value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            style.Font = new System.Drawing.Font(style.Font, value ? style.Font.Style | System.Drawing.FontStyle.Bold : style.Font.Style & ~System.Drawing.FontStyle.Bold);
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Sets the FontUnderline Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellFontUnderline(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, bool value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellFontUnderline(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, bool value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            style.Font = new System.Drawing.Font(style.Font, value ? style.Font.Style | System.Drawing.FontStyle.Underline : style.Font.Style & ~System.Drawing.FontStyle.Underline);
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Sets the ForeColor Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellForeColor(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Color value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellForeColor(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Color value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            style.ForeColor = value;
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Set the given style to the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="style">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void SetStyle(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, C1.Win.C1FlexGrid.CellStyle style, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void SetStyle(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, C1.Win.C1FlexGrid.CellStyle style, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            // Specific cell
            if (Row2 == -1 && Col2 == -1 || (Row1 == Row2 && Col1 == Col2))
            {
                vsGrid.SetCellStyle(Row1, Col1, style);
            }
            // Specific row
            else if (Row1 == Row2 && (Col1 + Col2 == vsGrid.Cols.Count))
            {
                vsGrid.Rows[Row1].Style = style;
            }
            // Specific column
            else if (Col1 == Col2 && (Row1 + Row2 == vsGrid.Rows.Count))
            {
                vsGrid.Cols[Col1].Style = style;
            }
            // Range
            else
            {
                C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
                range.Style = style;
            }
        }

        /// <summary>
        /// Return the style of the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static C1.Win.C1FlexGrid.CellStyle GetStyle(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static C1.Win.C1FlexGrid.CellStyle GetStyle(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = null;
            // Specific cell
            if (Row2 == -1 && Col2 == -1 || (Row1 == Row2 && Col1 == Col2))
            {
                style = vsGrid.GetCellStyle(Row1, Col1);
            }
            // Specific row
            else if (Row1 == Row2 && (Col1 + Col2 == vsGrid.Cols.Count))
            {
                style = vsGrid.Rows[Row1].Style;
            }
            // Specific column
            else if (Col1 == Col2 && (Row1 + Row2 == vsGrid.Rows.Count))
            {
                style = vsGrid.Cols[Col1].Style;
            }
            // Range
            else
            {
                C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);
                style = range.Style;
            }
            if (style == null)
                style = vsGrid.Styles.Normal.Clone();
            return style;
        }

        /// <summary>
        /// Sets the Picture Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellPicture(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Image value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellPicture(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Image value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, Col1, Row2, Col2);

            if (range.IsSingleCell && vsGrid.Cols[range.c1].DataType == typeof(Boolean))
            {
                range.StyleNew.BackgroundImage = value;
                range.StyleNew.BackgroundImageLayout = ImageAlignEnum.LeftCenter;
            }
            else
            {
                range.Image = value;
            }
        }

        /// <summary>
        /// Sets the PictureAlignment Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellPictureAlignment(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, C1.Win.C1FlexGrid.ImageAlignEnum value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellPictureAlignment(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, C1.Win.C1FlexGrid.ImageAlignEnum value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            C1.Win.C1FlexGrid.CellStyle style = GetStyle(vsGrid, Row1, Col1, Row2, Col2);
            style.ImageAlign = value;
            SetStyle(vsGrid, style, Row1, Col1, Row2, Col2);
        }

        /// <summary>
        /// Sets the Text Property for the specified range of cells
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value">The New Value to be stored</param>
        /// <param name="Row1">[Optional] - Start Row</param>
        /// <param name="Col1">[Optional] - Start Col</param>
        /// <param name="Row2">[Optional] - End Row</param>
        /// <param name="Col2">[Optional] - End Col</param>
#if TargetF2
        public static void setCellText(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#else
        public static void setCellText(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string value, int Row1 = -1, int Col1 = -1, int Row2 = -1, int Col2 = -1)
#endif
        {
            String[] cells = value.Split('\t');
            int colLimit = (Col2 == -1) ? Col1 : Col2;
            int cellIndex = 0;
            for (int i = Col1; i <= colLimit; i++)
            {
                C1.Win.C1FlexGrid.CellRange range = GetCellRange(vsGrid, Row1, i, Row2, i);
                if (cellIndex <= cells.Length - 1)
                {
                    if (cells[cellIndex] != null)
                    {
                        range.Data = cells[cellIndex];
                    }

                }
                cellIndex++;
            }
        }

        /// <summary>
        /// Draws a border around and within the selected cells.
        /// </summary>
        /// <param name="vsGrid"></param>
        /// <param name="Color">This parameter determines the color of the border.</param>
        /// <param name="Left">This parameter specify the width, in pixels, of the border to be drawn around the selection. Specify zero to remove the border, or any negative number to preserve the existing border.</param>
        /// <param name="Top">This parameter specify the width, in pixels, of the border to be drawn around the selection. Specify zero to remove the border, or any negative number to preserve the existing border.</param>
        /// <param name="Right">This parameter specify the width, in pixels, of the border to be drawn around the selection. Specify zero to remove the border, or any negative number to preserve the existing border.</param>
        /// <param name="Bottom">This parameter specify the width, in pixels, of the border to be drawn around the selection. Specify zero to remove the border, or any negative number to preserve the existing border.</param>
        /// <param name="Vertical">This parameter specify the width, in pixels, of the borders to be drawn inside the selection in the vertical and horizontal directions. Specify zero to remove the border, or any negative number to preserve the width of the existing border.</param>
        /// <param name="Horizontal">This parameter specify the width, in pixels, of the borders to be drawn inside the selection in the vertical and horizontal directions. Specify zero to remove the border, or any negative number to preserve the width of the existing border.</param>
#if TargetF2
        public static void CellBorder(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Color Color, int Left, int Top, int Right, int Bottom, int Vertical, int Horizontal)
#else
        public static void CellBorder(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, System.Drawing.Color Color, int Left, int Top, int Right, int Bottom, int Vertical, int Horizontal)
#endif
        {
            //Use CellBorder property (Use Style)
            //http://helpcentral.componentone.com/docs/vsflexgrid8/cellbordermethod.htm
            throw new NotImplementedException();
        }
        
        /// <summary>
        /// Obtains the numeric value of a cell
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="Row">The row of the vsFlex</param>
        /// <param name="Col">The column of the vsFlex</param>
#if TargetF2
        public static int ValueMatrix(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row, int Col)
#else
        public static int ValueMatrix(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row, int Col)
#endif
        {
            if (vsGrid[Row, Col] == null) return -1;
            string value = Convert.ToString(vsGrid[Row, Col]);
            int valueOut = 0;
            if (String.IsNullOrEmpty(value)) return 0;
            Int32.TryParse(value, out valueOut);
            return valueOut;


        }

        #region FormatString

        /// <summary>
        /// Assigns column widths, alignments, and fixed row and column text.
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="formatString">Format String</param>
        /// <remarks>
        /// Remarks
        /// Use FormatString at design time to define the following elements of the control: number of rows and columns, text for row and column headings, column width, and column alignment.
        /// The FormatString is made up of segments separated by pipe characters ('|'). The text between pipes defines a column, and it may contain the special alignment characters '&lt;', '^', or '&gt;', to align the entire column to the left, center, or right. The text is assigned to row zero, and its width defines the width of each column. The FormatString may also contain a semi-colon (";"), which causes the remaining of the string to be interpreted as row heading and width information. The text is assigned to column zero, and the longest string defines the width of column zero. If the first character in the FormatString is an equals sign ('='), then all non-fixed rows will have the same width.
        /// The control will create additional rows and columns to accommodate all fields defined by the FormatString, but it will not delete rows or columns if a few fields are specified.
        /// The FormatString property is obsolete. Use the Columns property page to set up your columns instead.
        /// </remarks>
#if TargetF2
        public static void setFormatString(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string formatString)
#else
        public static void setFormatString(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string formatString)
#endif
        {
            throw new NotImplementedException();   
        }

        /// <summary>
        /// Gets the FormatString specified for the control
        /// </summary>
        /// <param name="vsGrid">The Grid Control</param>
        /// <returns>The Format String</returns>
#if TargetF2
        public static string getFormatString(C1.Win.C1FlexGrid.C1FlexGrid vsGrid)
#else
        public static string getFormatString(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid)
#endif
        {
            throw new NotImplementedException();
        }

        #endregion


        #region EditMaxLength

        private static Dictionary<int, int> MaxLengths = new Dictionary<int, int>();

        /// <summary>
        /// Sets the maximum number of characters that can be entered in the editor.
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="value"></param>
#if TargetF2
        public static void SetEditMaxLength(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int value)
#else
        public static void SetEditMaxLength(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int value)
#endif
        {
            int hash = vsGrid.GetHashCode();
            if (MaxLengths.ContainsKey(hash))
            {
                //Extract it from the collection
                MaxLengths[hash] = value;
            }
            else
            {
                //Add it to the collection
                MaxLengths.Add(hash, value);

                vsGrid.StartEdit += new RowColEventHandler(delegate(object sender, RowColEventArgs e)
                {
                });

                vsGrid.SetupEditor += new RowColEventHandler(delegate(object sender, RowColEventArgs e)
                {
                    if (vsGrid.Editor is System.Windows.Forms.TextBox)
                    {
                        (vsGrid.Editor as System.Windows.Forms.TextBox).MaxLength = value;
                    }
                });

                //When disposed, remove it
                vsGrid.Disposed += new EventHandler(delegate(object eventsender, EventArgs eventArgs)
                {
                    MaxLengths.Remove(hash);
                });
            }
        }

        /// <summary>
        /// Gets the maximum number of characters that can be entered in the editor.
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <returns>The maximum number of characters that can be entered in the editor</returns>
#if TargetF2
        public static int GetEditMaxLength(C1.Win.C1FlexGrid.C1FlexGrid vsGrid)
#else
        public static int GetEditMaxLength(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid)
#endif
        {
            int hash = vsGrid.GetHashCode();
            if (MaxLengths.ContainsKey(hash))
            {
                return MaxLengths[hash];
            }
            return -1;
        }
        #endregion


        /// <summary>
        /// Returns the current selection ordered so that Row1 <= Row2 and Col1 <= Col2.
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="r1">Start Row</param>
        /// <param name="c1">Start Col</param>
        /// <param name="r2">End Row</param>
        /// <param name="c2">End Col</param>
#if TargetF2
        public static void GetSelection(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, out int r1, out int c1, out int r2, out int c2)
#else
        public static void GetSelection(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, out int r1, out int c1, out int r2, out int c2)
#endif
        {
            r1 = vsGrid.Selection.r1;
            c1 = vsGrid.Selection.c1;
            r2 = vsGrid.Selection.r2;
            c2 = vsGrid.Selection.c2;
        }

        /// <summary>
        /// Load values in the cache
        /// </summary>
        /// <param name="vsGrid">grid control</param>
        /// <param name="RowStart">Row start</param>
        /// <param name="Column">Column values</param>
        /// <returns>Key cache</returns>
#if TargetF2
        public static string LoadCacheFindRow(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int RowStart, int Column)
#else
        public static string LoadCacheFindRow(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int RowStart, int Column)
#endif
        {
            string sNewGuid = Guid.NewGuid().ToString();
            Dictionary<string, int> valuesColumn = new Dictionary<string, int>(vsGrid.Rows.Count);
            for (int iRow = RowStart; iRow < vsGrid.Rows.Count; iRow++)
            {
                string valueRow = Convert.ToString(vsGrid.GetData(iRow, Column));
                if (!valuesColumn.ContainsKey(valueRow))
                {
                    valuesColumn.Add(valueRow, iRow);
                }
            }
            cacheValuesFindRow.Add(sNewGuid, valuesColumn);
            return sNewGuid;
        }
        /// <summary>
        /// Remove cache values
        /// </summary>
        /// <param name="vsGrid">grid control</param>
        /// <param name="KeyCache">Key cache values</param>
#if TargetF2
        public static void UnloadCacheFindRow(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string KeyCache)
#else
        public static void UnloadCacheFindRow(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string KeyCache)
#endif
        {
            if (cacheValuesFindRow.ContainsKey(KeyCache))
            {
                cacheValuesFindRow.Remove(KeyCache);
            }
        }
        /// <summary>
        /// Finds a row that contains a specified value in a given column in the cache.
        /// </summary>
        /// <param name="vsGrid">Grid control extenxions</param>
        /// <param name="KeyCache">Key cache</param>
        /// <param name="strFind">Object to look for.</param>
        /// <param name="rowStart"> Index of the row where the search should start</param>
        /// <param name="col">Column to be searched.</param>
        /// <param name="caseSensitive">Case Sensitive </param>
        /// <param name="fullMatch">Full Match</param>
        /// <param name="wrap">Whether the search should stop at the bottom of the grid or wrap around and
        ///  restart from the first scrollable row </param>
        /// <returns>The index of the row that contains the data, or -1 if the objFind object is not found.</returns>
#if TargetF2
        public static int FindRowCache(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string KeyCache, string strFind, int rowStart, int col, bool caseSensitive, bool fullMatch, bool wrap)
#else
        public static int FindRowCache(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, string KeyCache, string strFind, int rowStart, int col, bool caseSensitive, bool fullMatch, bool wrap)
#endif
        {
            int lFlexRow = -1;
            if (cacheValuesFindRow.ContainsKey(KeyCache))
            {
                Dictionary<string, int> values = cacheValuesFindRow[KeyCache];
                if (values.ContainsKey(strFind))
                {
                    lFlexRow = values[strFind];
                }
            }
            else
            {
                lFlexRow = vsGrid.FindRow(strFind, rowStart, col, caseSensitive, fullMatch, wrap);
            }
            return lFlexRow;
        }

        /// <summary>
        /// Groups rows based on cell contents and calculates aggregate values and personalized  every row
        /// </summary>
        /// <param name="vsGrid">Grid Control</param>
        /// <param name="aggType">C1.Win.C1FlexGrid.AggregateEnum value that specifies the type of aggregate to calculate.</param>
        /// <param name="level">Outline level to assign to the new subtotal rows. This parameter allows the 
        ///	creation of multi-level subtotals and affects the display of the outline tree.</param>
        /// <param name="groupOn">Column used to detect group breaks.</param>
        /// <param name="totalOn">Column that contains values to be aggregated (usually numeric).</param>
#if TargetF2
        public static void SubtotalPersonalizeRow(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, AggregateEnum aggType, int level, int groupOn, int totalOn)
#else
        public static void SubtotalPersonalizeRow(this C1.Win.C1FlexGrid.C1FlexGrid vsGrid, AggregateEnum aggType, int level, int groupOn, int totalOn)
#endif
        {
            vsGrid.Subtotal(aggType, level, groupOn, totalOn);
            //Clone style for row
            for (int iRows = 1; iRows < vsGrid.Rows.Count; iRows++)
            {
                if (vsGrid.Rows[iRows].Style != null)
                {
                    C1.Win.C1FlexGrid.CellStyle clonCellStyle = vsGrid.Rows[iRows].Style.Clone();
                    vsGrid.Rows[iRows].Style = clonCellStyle;
                }
            }
        }


        #region "Utilities"
        private static C1.Win.C1FlexGrid.CellRange GetCellRange(C1.Win.C1FlexGrid.C1FlexGrid vsGrid, int Row1, int Col1, int Row2, int Col2)
        {
            if (Row1 < 0 && Col1 < 0)
            {
                throw new ArgumentException("Values Should be greater than 0");
            }
            else if (Row2 < 0 && Col2 < 0)
            {
                return vsGrid.GetCellRange(Row1, Col1);
            }
            else
            {
                return vsGrid.GetCellRange(Row1, Col1, Row2, Col2);
            }
        }
        #endregion
    }
}
