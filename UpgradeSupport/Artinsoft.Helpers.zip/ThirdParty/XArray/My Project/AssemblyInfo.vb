Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("VB Upgrade XArray")> 
<Assembly: AssemblyDescription("Artinsoft VB Upgrade XArray")> 
<Assembly: CLSCompliant(True)> 


'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("433f99ff-f6bd-441b-9c15-1647ff861c54")> 
